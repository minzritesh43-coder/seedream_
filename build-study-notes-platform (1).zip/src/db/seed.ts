import "dotenv/config";
import { db } from "./index";
import { bookmarks, notes, revisions, subjects } from "./schema";
import { seedNotes, seedSubjects } from "./seed-data";

async function main() {
  console.log("Clearing existing data…");
  await db.delete(revisions);
  await db.delete(bookmarks);
  await db.delete(notes);
  await db.delete(subjects);

  console.log(`Seeding ${seedSubjects.length} subjects…`);
  const insertedSubjects = await db
    .insert(subjects)
    .values(
      seedSubjects.map((s) => ({
        slug: s.slug,
        name: s.name,
        color: s.color,
        ink: s.ink,
        blurb: s.blurb,
      })),
    )
    .returning({ id: subjects.id, slug: subjects.slug });

  const subjectIdBySlug = new Map(insertedSubjects.map((s) => [s.slug, s.id]));

  console.log(`Seeding ${seedNotes.length} notes…`);
  for (const n of seedNotes) {
    const subjectId = subjectIdBySlug.get(n.subject);
    if (!subjectId) throw new Error(`Unknown subject: ${n.subject}`);
    await db.insert(notes).values({
      slug: n.slug,
      title: n.title,
      excerpt: n.excerpt,
      subjectId,
      author: n.author,
      grade: n.grade,
      blocks: n.blocks,
      readMinutes: n.readMinutes,
      views: n.views,
      featured: n.featured ?? false,
      createdAt: new Date(n.createdAt),
    });
  }

  console.log("Done ✓");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
