import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  serial,
  timestamp,
  uniqueIndex,
  varchar,
  text,
} from "drizzle-orm/pg-core";

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 60 }).notNull().unique(),
  name: varchar("name", { length: 80 }).notNull(),
  color: varchar("color", { length: 16 }).notNull(),
  ink: varchar("ink", { length: 16 }).notNull().default("#F7F2E8"),
  blurb: text("blurb").notNull().default(""),
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 140 }).notNull().unique(),
  title: varchar("title", { length: 220 }).notNull(),
  excerpt: text("excerpt").notNull(),
  subjectId: integer("subject_id")
    .notNull()
    .references(() => subjects.id, { onDelete: "cascade" }),
  author: varchar("author", { length: 90 }).notNull(),
  grade: varchar("grade", { length: 24 }).notNull().default("Class 10"),
  blocks: jsonb("blocks").notNull(),
  readMinutes: integer("read_minutes").notNull().default(4),
  views: integer("views").notNull().default(0),
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: false })
    .notNull()
    .defaultNow(),
});

export const bookmarks = pgTable(
  "bookmarks",
  {
    id: serial("id").primaryKey(),
    visitorId: varchar("visitor_id", { length: 72 }).notNull(),
    noteId: integer("note_id")
      .notNull()
      .references(() => notes.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: false })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("bookmarks_visitor_note_uniq").on(t.visitorId, t.noteId)],
);

export const revisions = pgTable(
  "revisions",
  {
    id: serial("id").primaryKey(),
    visitorId: varchar("visitor_id", { length: 72 }).notNull(),
    noteId: integer("note_id")
      .notNull()
      .references(() => notes.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: false })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("revisions_visitor_idx").on(t.visitorId)],
);

export type Subject = typeof subjects.$inferSelect;
export type Note = typeof notes.$inferSelect;
