import Link from "next/link";
import { ArrowRight, ArrowUpRight, Eye, Flame, NotebookPen, Timer, Users } from "lucide-react";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import HomeHero from "@/components/home-hero";
import Ticker from "@/components/ticker";
import SubjectIndex from "@/components/subject-index";
import NoteRow from "@/components/note-row";
import SubjectChip from "@/components/subject-chip";
import Reveal from "@/components/reveal";
import { getLibraryStats, getNotes, getSubjectsWithCounts, type NoteListItem } from "@/lib/queries";

export const dynamic = "force-dynamic";

function SectionHead({ index, title, aside }: { index: string; title: string; aside?: string }) {
  return (
    <Reveal className="flex flex-wrap items-end justify-between gap-4 border-b border-ink pb-5">
      <div>
        <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">{index}</p>
        <h2 className="mt-2 font-serif text-3xl font-semibold tracking-tight md:text-5xl">{title}</h2>
      </div>
      {aside && (
        <p className="max-w-xs text-right font-serif text-sm italic text-fog md:text-base">{aside}</p>
      )}
    </Reveal>
  );
}

function FeaturedLead({ note }: { note: NoteListItem }) {
  return (
    <Link
      href={`/notes/${note.slug}`}
      className="group relative flex h-full min-h-[26rem] flex-col overflow-hidden border border-ink p-8 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[8px_8px_0_0_#17140c] md:p-10"
      style={{
        backgroundColor: `color-mix(in srgb, ${note.subject.color} 9%, #fdfaF4)`,
      }}
    >
      <span
        aria-hidden
        className="pointer-events-none absolute -right-6 -top-12 select-none font-serif text-[11rem] font-black italic leading-none opacity-[0.07]"
      >
        N°01
      </span>
      <div className="flex items-center justify-between">
        <SubjectChip {...note.subject} asLink={false} />
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">
          Pinned this week
        </span>
      </div>
      <h3 className="mt-8 max-w-xl font-serif text-4xl font-semibold leading-[1.04] tracking-tight transition-colors duration-300 group-hover:text-vermilion-deep md:text-[3.4rem]">
        {note.title}
      </h3>
      <p className="mt-5 max-w-lg text-[1.05rem] leading-relaxed text-soot">{note.excerpt}</p>
      <div className="mt-auto flex items-center justify-between pt-10">
        <div className="flex flex-wrap items-center gap-4 font-mono text-[10px] uppercase tracking-[0.16em] text-fog">
          <span>by {note.author}</span>
          <span className="inline-flex items-center gap-1.5">
            <Timer className="h-3.5 w-3.5" /> {note.readMinutes} min read
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Eye className="h-3.5 w-3.5" /> {note.views} reads
          </span>
        </div>
        <span className="flex h-11 w-11 items-center justify-center rounded-full border border-ink transition-all duration-300 group-hover:bg-ink group-hover:text-paper">
          <ArrowUpRight className="h-5 w-5 transition-transform duration-300 group-hover:rotate-45" />
        </span>
      </div>
    </Link>
  );
}

function FeaturedSide({ note, n }: { note: NoteListItem; n: number }) {
  return (
    <Link
      href={`/notes/${note.slug}`}
      className="group flex flex-1 flex-col border border-ink/80 bg-cream p-7 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[7px_7px_0_0_#17140c]"
    >
      <div className="flex items-center justify-between">
        <SubjectChip {...note.subject} asLink={false} size="sm" />
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">
          N°{String(n).padStart(2, "0")}
        </span>
      </div>
      <h3 className="mt-5 font-serif text-[1.65rem] font-semibold leading-[1.1] tracking-tight transition-colors duration-300 group-hover:text-vermilion-deep">
        {note.title}
      </h3>
      <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-soot/90">{note.excerpt}</p>
      <p className="mt-auto pt-5 font-mono text-[10px] uppercase tracking-[0.16em] text-fog">
        {note.author.split(" ")[0]} · {note.readMinutes} min
      </p>
    </Link>
  );
}

export default async function HomePage() {
  const [stats, subjects, featured, latest, all] = await Promise.all([
    getLibraryStats(),
    getSubjectsWithCounts(),
    getNotes({ featuredOnly: true }),
    getNotes({ limit: 6 }),
    getNotes({ limit: 100 }),
  ]);

  const latestBySubject = new Map<string, string>();
  for (const n of all) {
    if (!latestBySubject.has(n.subject.slug)) latestBySubject.set(n.subject.slug, n.title);
  }

  const lead = featured[0] ?? latest[0];
  const side = (featured.length > 1 ? featured.slice(1, 3) : latest.slice(1, 3));

  return (
    <main className="min-h-screen">
      <SiteHeader />

      <HomeHero
        stats={[
          { value: stats.noteCount, label: "notes on the shelf" },
          { value: stats.subjectCount, label: "subjects covered" },
          { value: stats.authorCount, label: "classmate authors" },
          { value: stats.totalMinutes, label: "minutes of revision" },
        ]}
        subjects={subjects.map((s) => ({ name: s.name, color: s.color }))}
      />

      <Ticker subjects={subjects} />

      {/* ——— featured ——— */}
      <section className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <SectionHead
          index="01 — Featured"
          title="Pinned to the front of the class."
          aside="The notes classmates keep coming back to."
        />
        <div className="mt-10 grid gap-5 lg:grid-cols-5">
          <Reveal className="lg:col-span-3" delay={0.05}>
            {lead && <FeaturedLead note={lead} />}
          </Reveal>
          <div className="flex flex-col gap-5 lg:col-span-2">
            {side.map((n, i) => (
              <Reveal key={n.slug} delay={0.12 + i * 0.08} className="flex flex-1">
                <FeaturedSide note={n} n={i + 2} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ——— subject index ——— */}
      <section className="pb-20 md:pb-28">
        <div className="mx-auto max-w-7xl px-5 pb-10 md:px-8">
          <SectionHead
            index="02 — The shelves"
            title="Eight subjects, one notebook."
            aside="Pick a shelf. Everything on it is fair game in the exam hall."
          />
        </div>
        <Reveal>
          <SubjectIndex
            rows={subjects.map((s) => ({ ...s, latestTitle: latestBySubject.get(s.slug) }))}
          />
        </Reveal>
      </section>

      {/* ——— latest ——— */}
      <section className="mx-auto max-w-7xl px-5 pb-24 md:px-8 md:pb-32">
        <SectionHead
          index="03 — Fresh ink"
          title="Latest notes off the desk."
          aside="Newest explanations, still warm."
        />
        <div className="mt-8">
          {latest.map((n, i) => (
            <Reveal key={n.slug} delay={Math.min(i * 0.05, 0.3)}>
              <NoteRow note={n} index={i} />
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-10 flex justify-center">
          <Link
            href="/notes"
            className="group inline-flex items-center gap-2.5 rounded-full border border-ink px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.16em] transition-all duration-300 hover:bg-ink hover:text-paper"
          >
            Browse the full archive
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </Reveal>
      </section>

      {/* ——— manifesto ——— */}
      <section id="manifesto" className="rule-lines scroll-mt-20 border-y border-ink/60 bg-cream/50">
        <div className="mx-auto grid max-w-7xl gap-14 px-5 py-20 md:grid-cols-2 md:px-8 md:py-28">
          <Reveal>
            <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">
              04 — The manifesto
            </p>
            <h2 className="mt-4 font-serif text-3xl font-semibold leading-[1.15] tracking-tight md:text-[2.9rem]">
              Explaining is the{" "}
              <em className="text-vermilion">cheapest revision</em> ever invented.
            </h2>
            <p className="mt-6 max-w-md leading-relaxed text-soot">
              Psychologists call it the <em>protégé effect</em>: students who teach
              material understand it more deeply than students who only re-read it.
              A shared notebook turns that science into a habit — you revise by
              writing, and the class revises by reading.
            </p>
          </Reveal>
          <div className="flex flex-col justify-center gap-8">
            {[
              {
                icon: NotebookPen,
                n: "01",
                title: "Revise while you write",
                body: "Tidying a chapter into a one-page note forces the chapter to actually fit in your head first.",
              },
              {
                icon: Users,
                n: "02",
                title: "The whole class levels up",
                body: "Your explanation of trig might be the one sentence that finally makes it click for someone else.",
              },
              {
                icon: Flame,
                n: "03",
                title: "A quiet daily streak",
                body: "Save notes to your shelf, mark them revised each evening, and watch the streak counter grow.",
              },
            ].map((item, i) => (
              <Reveal key={item.n} delay={i * 0.08} className="flex gap-5 border-b border-ink/15 pb-8 last:border-b-0">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-ink bg-paper">
                  <item.icon className="h-5 w-5 text-vermilion" />
                </span>
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-fog">{item.n}</p>
                  <h3 className="mt-1 font-serif text-xl font-semibold tracking-tight md:text-2xl">
                    {item.title}
                  </h3>
                  <p className="mt-2 max-w-md text-[15px] leading-relaxed text-soot/90">{item.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ——— tonight CTA ——— */}
      <section className="relative overflow-hidden bg-ink text-paper">
        <div className="dot-grid pointer-events-none absolute inset-0 opacity-20" />
        <div className="relative mx-auto flex max-w-7xl flex-col items-start gap-8 px-5 py-20 md:flex-row md:items-end md:justify-between md:px-8 md:py-24">
          <Reveal>
            <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">
              05 — Tonight&apos;s plan
            </p>
            <h2 className="mt-4 max-w-xl font-serif text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
              Save one note. Revise one note. Repeat tomorrow.
            </h2>
          </Reveal>
          <Reveal delay={0.1} className="flex flex-wrap gap-4">
            <Link
              href="/revise"
              className="group inline-flex items-center gap-2.5 rounded-full bg-paper px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.16em] text-ink transition-all duration-300 hover:bg-vermilion hover:text-paper"
            >
              Open my revision shelf
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
            <Link
              href="/write"
              className="inline-flex items-center gap-2.5 rounded-full border border-paper/40 px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.16em] text-paper transition-all duration-300 hover:border-paper hover:bg-paper hover:text-ink"
            >
              Write tonight&apos;s note
            </Link>
          </Reveal>
        </div>
      </section>

      <Ticker subjects={subjects} invert slow />

      <SiteFooter subjects={subjects} />
    </main>
  );
}
