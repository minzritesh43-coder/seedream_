import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight } from "lucide-react";
import type { Metadata } from "next";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import NoteCard from "@/components/note-card";
import Reveal from "@/components/reveal";
import { getNotes, getSubjectsWithCounts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const subjects = await getSubjectsWithCounts();
  const subject = subjects.find((s) => s.slug === slug);
  if (!subject) return { title: "Subject not found" };
  return { title: `${subject.name} notes`, description: subject.blurb };
}

export default async function SubjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const subjects = await getSubjectsWithCounts();
  const subject = subjects.find((s) => s.slug === slug);
  if (!subject) notFound();

  const notes = await getNotes({ subjectSlug: slug, limit: 100 });
  const totalMinutes = notes.reduce((sum, n) => sum + n.readMinutes, 0);

  return (
    <main className="min-h-screen">
      <SiteHeader />

      {/* masthead in the subject's ink */}
      <header style={{ backgroundColor: subject.color }} className="border-b border-ink">
        <div className="mx-auto max-w-7xl px-5 pb-16 pt-32 md:px-8 md:pt-40" style={{ color: subject.ink }}>
          <Reveal>
            <Link
              href="/notes"
              className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] opacity-70 transition-opacity hover:opacity-100"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              All notes
            </Link>
          </Reveal>
          <Reveal delay={0.06}>
            <p className="mt-10 font-mono text-[11px] uppercase tracking-[0.28em] opacity-70">
              Shelf {String(subjects.findIndex((s) => s.slug === slug) + 1).padStart(2, "0")} ·{" "}
              {notes.length} {notes.length === 1 ? "note" : "notes"} · {totalMinutes} min of revision
            </p>
            <h1 className="mt-4 font-serif text-[clamp(3rem,9vw,7.5rem)] font-semibold leading-[0.95] tracking-[-0.02em]">
              {subject.name}
            </h1>
            <p className="mt-6 max-w-lg text-lg leading-relaxed opacity-85">{subject.blurb}</p>
          </Reveal>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-5 py-14 md:px-8 md:py-20">
        {notes.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {notes.map((n, i) => (
              <Reveal key={n.slug} delay={Math.min(i * 0.06, 0.35)}>
                <NoteCard note={n} index={i} />
              </Reveal>
            ))}
          </div>
        ) : (
          <div className="mx-auto max-w-lg border border-dashed border-ink/40 bg-cream p-12 text-center">
            <p className="font-serif text-2xl italic">This shelf is still empty.</p>
            <p className="mt-3 text-sm leading-relaxed text-soot/80">
              Be the classmate who writes the first {subject.name} note.
            </p>
            <Link
              href="/write"
              className="mt-6 inline-flex items-center gap-2 rounded-full border border-ink bg-vermilion px-6 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-paper shadow-[3px_3px_0_0_#17140c]"
            >
              Write it now
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        )}
      </section>

      {/* other shelves strip */}
      <section className="border-t border-ink/60">
        <div className="scroll-slim flex overflow-x-auto">
          {subjects
            .filter((s) => s.slug !== slug)
            .map((s) => (
              <Link
                key={s.slug}
                href={`/subjects/${s.slug}`}
                className="group flex shrink-0 items-center gap-3 border-r border-ink/20 px-8 py-6 font-mono text-[11px] uppercase tracking-[0.18em] transition-colors duration-300 last:border-r-0 hover:bg-(--row) hover:text-(--rowink)"
                style={{ "--row": s.color, "--rowink": s.ink } as React.CSSProperties}
              >
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: s.color }} />
                {s.name}
                <ArrowRight className="h-3.5 w-3.5 opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100" />
              </Link>
            ))}
        </div>
      </section>

      <SiteFooter subjects={subjects} />
    </main>
  );
}
