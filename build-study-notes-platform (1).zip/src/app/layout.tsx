import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Fraunces, Instrument_Sans, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  axes: ["opsz"],
});

const instrument = Instrument_Sans({
  subsets: ["latin"],
  variable: "--font-instrument",
});

const jbmono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jbmono",
});

export const metadata: Metadata = {
  title: {
    default: "Commonplace — the class notebook, written out loud",
    template: "%s — Commonplace",
  },
  description:
    "A living study-notes blog for the whole class. Share notes on Maths, Physics, Chemistry and more — revise faster, help classmates, and build a writing habit that sticks.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body
        className={`${fraunces.variable} ${instrument.variable} ${jbmono.variable} font-sans grain antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
