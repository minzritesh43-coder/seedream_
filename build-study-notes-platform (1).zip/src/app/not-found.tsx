import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import SiteHeader from "@/components/site-header";

export default function NotFound() {
  return (
    <main className="min-h-screen">
      <SiteHeader />
      <div className="rule-lines flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <p className="font-mono text-[11px] uppercase tracking-[0.3em] text-vermilion">
          Page 404 — torn out
        </p>
        <h1 className="mt-6 font-serif text-[clamp(3rem,10vw,8rem)] font-semibold italic leading-none tracking-tight">
          This page never
          <br />
          made it to class.
        </h1>
        <p className="mt-8 max-w-md leading-relaxed text-soot">
          The note you are looking for was either never written or is hiding in
          someone&apos;s backpack. The archive, however, is very real.
        </p>
        <Link
          href="/notes"
          className="group mt-10 inline-flex items-center gap-2.5 rounded-full border border-ink bg-ink px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.16em] text-paper transition-colors duration-300 hover:bg-vermilion"
        >
          <ArrowLeft className="h-4 w-4 transition-transform duration-300 group-hover:-translate-x-1" />
          Back to the archive
        </Link>
      </div>
    </main>
  );
}
