import { NextRequest, NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookmarks, notes, revisions, subjects } from "@/db/schema";

function dayKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export async function GET(req: NextRequest) {
  const visitor = req.nextUrl.searchParams.get("visitor") ?? "";
  if (!visitor) {
    return NextResponse.json({
      bookmarks: [],
      revisionTotal: 0,
      streakDays: 0,
      activeDays: 0,
    });
  }

  const saved = await db
    .select({
      noteId: notes.id,
      slug: notes.slug,
      title: notes.title,
      excerpt: notes.excerpt,
      readMinutes: notes.readMinutes,
      author: notes.author,
      grade: notes.grade,
      createdAt: bookmarks.createdAt,
      subjectSlug: subjects.slug,
      subjectName: subjects.name,
      subjectColor: subjects.color,
      subjectInk: subjects.ink,
    })
    .from(bookmarks)
    .innerJoin(notes, eq(bookmarks.noteId, notes.id))
    .innerJoin(subjects, eq(notes.subjectId, subjects.id))
    .where(eq(bookmarks.visitorId, visitor))
    .orderBy(desc(bookmarks.createdAt));

  const logs = await db
    .select({ createdAt: revisions.createdAt })
    .from(revisions)
    .where(eq(revisions.visitorId, visitor))
    .orderBy(desc(revisions.createdAt));

  const daySet = new Set(logs.map((l) => dayKey(l.createdAt)));
  const activeDays = daySet.size;

  // Walk backwards from today; a today-miss still counts if yesterday was active.
  let streakDays = 0;
  const cursor = new Date();
  if (!daySet.has(dayKey(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
  }
  while (daySet.has(dayKey(cursor))) {
    streakDays += 1;
    cursor.setDate(cursor.getDate() - 1);
  }

  return NextResponse.json({
    bookmarks: saved,
    revisionTotal: logs.length,
    streakDays,
    activeDays,
  });
}
