import { NextResponse } from "next/server";
import { getSubjectsWithCounts } from "@/lib/queries";

export async function GET() {
  const subjects = await getSubjectsWithCounts();
  return NextResponse.json({ subjects });
}
