import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { notes, subjects } from "@/db/schema";
import { getNotes } from "@/lib/queries";
import { estimateMinutes, parseNotebookSyntax, slugify } from "@/lib/note-syntax";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const subject = url.searchParams.get("subject") ?? undefined;
  const q = url.searchParams.get("q") ?? undefined;
  const featured = url.searchParams.get("featured") === "1";
  const limit = Number(url.searchParams.get("limit") ?? "100");

  const data = await getNotes({ subjectSlug: subject, query: q, featuredOnly: featured, limit });
  return NextResponse.json({ notes: data });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const title = String(body.title ?? "").trim();
    const subjectSlug = String(body.subjectSlug ?? "").trim();
    const author = String(body.author ?? "").trim() || "Anonymous";
    const grade = String(body.grade ?? "").trim() || "Class 10";
    const excerpt = String(body.excerpt ?? "").trim();
    const content = String(body.content ?? "");

    if (title.length < 4) {
      return NextResponse.json({ error: "Give your note a proper title (at least 4 characters)." }, { status: 400 });
    }
    if (content.trim().length < 40) {
      return NextResponse.json({ error: "The note is too short — classmates need substance (at least 40 characters)." }, { status: 400 });
    }
    if (!excerpt) {
      return NextResponse.json({ error: "Write a one-line summary so classmates know what this note covers." }, { status: 400 });
    }

    const subjectRows = await db.select().from(subjects).where(eq(subjects.slug, subjectSlug)).limit(1);
    if (!subjectRows.length) {
      return NextResponse.json({ error: "Pick a valid subject." }, { status: 400 });
    }

    const blocks = parseNotebookSyntax(content);
    if (!blocks.length) {
      return NextResponse.json({ error: "Could not parse any content blocks." }, { status: 400 });
    }

    const baseSlug = slugify(title);
    let slug = baseSlug;
    let attempt = 2;
    for (;;) {
      const clash = await db.select({ id: notes.id }).from(notes).where(eq(notes.slug, slug)).limit(1);
      if (!clash.length) break;
      slug = `${baseSlug}-${attempt++}`;
    }

    const { minutes } = estimateMinutes(blocks);

    const [created] = await db
      .insert(notes)
      .values({
        slug,
        title,
        excerpt,
        subjectId: subjectRows[0].id,
        author,
        grade,
        blocks,
        readMinutes: minutes,
        featured: false,
      })
      .returning({ slug: notes.slug });

    return NextResponse.json({ ok: true, slug: created.slug, readMinutes: minutes }, { status: 201 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Something went wrong publishing the note." }, { status: 500 });
  }
}
