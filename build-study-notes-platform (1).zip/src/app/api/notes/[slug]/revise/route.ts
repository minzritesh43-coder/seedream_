import { NextRequest, NextResponse } from "next/server";
import { and, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { notes, revisions } from "@/db/schema";

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const visitor = String(body.visitorId ?? "").slice(0, 72);
  if (!visitor) return NextResponse.json({ error: "visitorId required" }, { status: 400 });

  const noteRows = await db.select({ id: notes.id }).from(notes).where(eq(notes.slug, slug)).limit(1);
  if (!noteRows.length) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const noteId = noteRows[0].id;

  // One revision log per visitor per note per day keeps the streak honest.
  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);
  const todays = await db
    .select({ id: revisions.id })
    .from(revisions)
    .where(and(eq(revisions.visitorId, visitor), eq(revisions.noteId, noteId), gte(revisions.createdAt, dayStart)))
    .limit(1);

  if (todays.length) {
    return NextResponse.json({ ok: true, alreadyLogged: true });
  }

  await db.insert(revisions).values({ visitorId: visitor, noteId });
  return NextResponse.json({ ok: true, alreadyLogged: false });
}
