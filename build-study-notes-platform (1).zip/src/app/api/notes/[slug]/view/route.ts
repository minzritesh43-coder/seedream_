import { NextRequest, NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { notes } from "@/db/schema";

export async function POST(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  await db
    .update(notes)
    .set({ views: sql`${notes.views} + 1` })
    .where(eq(notes.slug, slug));
  return NextResponse.json({ ok: true });
}
