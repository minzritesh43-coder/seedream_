import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { bookmarks, notes } from "@/db/schema";

async function findNoteId(slug: string) {
  const rows = await db.select({ id: notes.id }).from(notes).where(eq(notes.slug, slug)).limit(1);
  return rows[0]?.id ?? null;
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const visitor = req.nextUrl.searchParams.get("visitor") ?? "";
  if (!visitor) return NextResponse.json({ saved: false });
  const noteId = await findNoteId(slug);
  if (!noteId) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const rows = await db
    .select({ id: bookmarks.id })
    .from(bookmarks)
    .where(and(eq(bookmarks.visitorId, visitor), eq(bookmarks.noteId, noteId)))
    .limit(1);
  return NextResponse.json({ saved: rows.length > 0 });
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const visitor = String(body.visitorId ?? "").slice(0, 72);
  if (!visitor) return NextResponse.json({ error: "visitorId required" }, { status: 400 });

  const noteId = await findNoteId(slug);
  if (!noteId) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const existing = await db
    .select({ id: bookmarks.id })
    .from(bookmarks)
    .where(and(eq(bookmarks.visitorId, visitor), eq(bookmarks.noteId, noteId)))
    .limit(1);

  if (existing.length) {
    await db.delete(bookmarks).where(eq(bookmarks.id, existing[0].id));
    return NextResponse.json({ saved: false });
  }

  await db.insert(bookmarks).values({ visitorId: visitor, noteId });
  return NextResponse.json({ saved: true });
}
