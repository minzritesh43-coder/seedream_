import { NextRequest, NextResponse } from "next/server";
import { getNoteBySlug } from "@/lib/queries";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ slug: string }> }) {
  const { slug } = await ctx.params;
  const note = await getNoteBySlug(slug);
  if (!note) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ note });
}
