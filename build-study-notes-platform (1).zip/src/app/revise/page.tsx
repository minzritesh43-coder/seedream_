"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Bookmark,
  CalendarDays,
  Flame,
  Info,
  LoaderCircle,
  PenLine,
  Repeat2,
  Timer,
  X,
} from "lucide-react";
import SiteHeader from "@/components/site-header";
import { getVisitorId } from "@/lib/visitor";

type SavedNote = {
  noteId: number;
  slug: string;
  title: string;
  excerpt: string;
  readMinutes: number;
  author: string;
  subjectSlug: string;
  subjectName: string;
  subjectColor: string;
  subjectInk: string;
};

type MeData = {
  bookmarks: SavedNote[];
  revisionTotal: number;
  streakDays: number;
  activeDays: number;
};

export default function RevisePage() {
  const [data, setData] = useState<MeData | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/me?visitor=${encodeURIComponent(getVisitorId())}`);
      const json = await res.json();
      setData(json);
    } catch {
      setData({ bookmarks: [], revisionTotal: 0, streakDays: 0, activeDays: 0 });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const removeSaved = async (slug: string) => {
    setData((d) =>
      d ? { ...d, bookmarks: d.bookmarks.filter((b) => b.slug !== slug) } : d,
    );
    await fetch(`/api/notes/${slug}/bookmark`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ visitorId: getVisitorId() }),
    }).catch(() => {});
  };

  const stats = [
    {
      icon: Flame,
      value: data?.streakDays ?? 0,
      label: data?.streakDays === 1 ? "day streak" : "day streak",
      accent: true,
    },
    { icon: Bookmark, value: data?.bookmarks.length ?? 0, label: "notes on your shelf" },
    { icon: Repeat2, value: data?.revisionTotal ?? 0, label: "revisions logged" },
    { icon: CalendarDays, value: data?.activeDays ?? 0, label: "active days so far" },
  ];

  return (
    <main className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto max-w-7xl px-5 pt-28 md:px-8 md:pt-36">
        <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">
          Your corner of the notebook
        </p>
        <h1 className="mt-3 max-w-4xl font-serif text-[clamp(2.6rem,6.5vw,5.5rem)] font-semibold leading-[1.02] tracking-tight">
          Tonight&apos;s revision shelf.
        </h1>
        <p className="mt-5 max-w-lg text-lg leading-relaxed text-soot">
          Save the notes worth a second read, mark each one revised as you go,
          and let the streak quietly guilt-trip tomorrow-you into showing up.
        </p>

        {/* stats */}
        <div className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className={
                s.accent
                  ? "border border-ink bg-vermilion p-6 text-paper shadow-[5px_5px_0_0_#17140c]"
                  : "border border-ink/60 bg-cream p-6"
              }
            >
              <s.icon className={s.accent ? "h-5 w-5" : "h-5 w-5 text-vermilion"} />
              <p className="mt-4 font-mono text-4xl font-medium tracking-tight md:text-5xl">
                {loading ? "–" : s.value}
              </p>
              <p
                className={`mt-2 font-mono text-[9px] uppercase tracking-[0.2em] ${
                  s.accent ? "text-paper/75" : "text-fog"
                }`}
              >
                {s.label}
              </p>
            </div>
          ))}
        </div>

        {/* shelf */}
        <div className="mt-16 grid gap-10 pb-24 lg:grid-cols-[1fr_320px]">
          <section>
            <h2 className="flex items-baseline justify-between border-b border-ink pb-4">
              <span className="font-serif text-2xl font-semibold tracking-tight md:text-3xl">
                Saved for revision
              </span>
              <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">
                {loading ? "" : `${data?.bookmarks.length ?? 0} saved`}
              </span>
            </h2>

            {loading ? (
              <div className="flex items-center gap-3 py-16 font-mono text-[11px] uppercase tracking-[0.2em] text-fog">
                <LoaderCircle className="h-4 w-4 animate-spin" />
                Dusting the shelves…
              </div>
            ) : data && data.bookmarks.length ? (
              <ul className="flex flex-col divide-y divide-ink/12">
                {data.bookmarks.map((b, i) => (
                  <li key={b.slug} className="group flex items-baseline gap-5 py-6">
                    <span className="font-mono text-xs tracking-[0.18em] text-fog">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div className="min-w-0 flex-1">
                      <Link
                        href={`/notes/${b.slug}`}
                        className="block truncate font-serif text-xl font-semibold tracking-tight transition-colors hover:text-vermilion-deep md:text-2xl"
                      >
                        {b.title}
                      </Link>
                      <div className="mt-2 flex flex-wrap items-center gap-3 font-mono text-[9px] uppercase tracking-[0.16em] text-fog">
                        <span
                          className="rounded-full px-2.5 py-1"
                          style={{ backgroundColor: b.subjectColor, color: b.subjectInk }}
                        >
                          {b.subjectName}
                        </span>
                        <span className="inline-flex items-center gap-1">
                          <Timer className="h-3 w-3" />
                          {b.readMinutes} min
                        </span>
                        <span>by {b.author.split(" ")[0]}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/notes/${b.slug}`}
                        className="inline-flex items-center gap-1.5 rounded-full border border-ink/40 px-3.5 py-1.5 font-mono text-[9px] uppercase tracking-[0.14em] text-soot transition-all duration-300 hover:border-ink hover:bg-ink hover:text-paper"
                      >
                        Study now
                        <ArrowRight className="h-3 w-3" />
                      </Link>
                      <button
                        onClick={() => removeSaved(b.slug)}
                        aria-label={`Remove ${b.title}`}
                        className="rounded-full p-1.5 text-fog opacity-0 transition-all duration-300 hover:bg-ink/8 hover:text-ink group-hover:opacity-100"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="mt-8 border border-dashed border-ink/40 bg-cream p-10 text-center">
                <p className="font-serif text-2xl italic">Your shelf is empty.</p>
                <p className="mx-auto mt-3 max-w-sm text-sm leading-relaxed text-soot/80">
                  Open any note and hit “Save for revision” — it lands here,
                  waiting for tonight.
                </p>
                <Link
                  href="/notes"
                  className="mt-6 inline-flex items-center gap-2 rounded-full border border-ink bg-ink px-6 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-paper transition-colors hover:bg-vermilion"
                >
                  Browse the archive
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            )}
          </section>

          {/* how it works */}
          <aside className="h-fit border border-ink bg-cream p-7 shadow-[6px_6px_0_0_rgba(23,20,12,0.14)] lg:sticky lg:top-28">
            <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-fog">
              <Info className="h-3.5 w-3.5" />
              How the streak works
            </p>
            <ol className="mt-5 flex flex-col gap-4 text-sm leading-relaxed text-soot">
              <li className="flex gap-3">
                <span className="font-mono text-[10px] text-vermilion">01</span>
                Open any note and tap <em>“Mark as revised”</em> — one honest log
                per note, per day.
              </li>
              <li className="flex gap-3">
                <span className="font-mono text-[10px] text-vermilion">02</span>
                Revise on consecutive evenings and the flame counter climbs.
              </li>
              <li className="flex gap-3">
                <span className="font-mono text-[10px] text-vermilion">03</span>
                Feeling generous? Turn tonight&apos;s revision into a note the
                class can use.
              </li>
            </ol>
            <Link
              href="/write"
              className="mt-6 flex items-center justify-center gap-2 rounded-full border border-ink bg-vermilion py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-paper shadow-[3px_3px_0_0_#17140c] transition-all duration-300 hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0_0_#17140c]"
            >
              <PenLine className="h-3.5 w-3.5" />
              Write a note
            </Link>
          </aside>
        </div>
      </div>
    </main>
  );
}
