import SiteHeader from "@/components/site-header";
import WriteForm from "@/components/write-form";
import { getSubjectsWithCounts } from "@/lib/queries";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Write a note",
  description:
    "Turn tonight's revision into a note the whole class can use. Writing is remembering.",
};

export default async function WritePage() {
  const subjects = await getSubjectsWithCounts();

  return (
    <main className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto max-w-7xl px-5 pt-28 md:px-8 md:pt-36">
        <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">
          The writing desk
        </p>
        <h1 className="mt-3 max-w-4xl font-serif text-[clamp(2.4rem,6vw,5rem)] font-semibold leading-[1.02] tracking-tight">
          Tonight&apos;s revision, typeset for the class.
        </h1>
        <p className="mt-5 max-w-xl text-lg leading-relaxed text-soot">
          Explain one thing well. It counts as your revision for the day — and it
          might be the explanation a classmate has been waiting for.
        </p>
      </div>
      <div className="mt-12 border-t border-ink/60 pt-10">
        <WriteForm subjects={subjects} />
      </div>
    </main>
  );
}
