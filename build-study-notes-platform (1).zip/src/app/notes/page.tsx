import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import NotesBrowser from "@/components/notes-browser";
import { getNotes, getSubjectsWithCounts } from "@/lib/queries";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "All notes",
  description: "Every study note in the class notebook — filter by subject, search by topic.",
};

export default async function NotesPage() {
  const [notes, subjects] = await Promise.all([getNotes({ limit: 200 }), getSubjectsWithCounts()]);

  return (
    <main className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto max-w-7xl px-5 pt-28 md:px-8 md:pt-36">
        <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">
          The archive
        </p>
        <h1 className="mt-3 max-w-4xl font-serif text-[clamp(2.6rem,6.5vw,5.5rem)] font-semibold leading-[1.02] tracking-tight">
          Every note in the notebook.
        </h1>
        <p className="mt-5 max-w-lg text-lg leading-relaxed text-soot">
          Search a topic, pick a subject, or sort by the quickest reads when you
          only have ten minutes before the bell.
        </p>
      </div>
      <div className="mt-10 border-t border-ink/60">
        <NotesBrowser notes={notes} subjects={subjects} />
      </div>
      <SiteFooter subjects={subjects} />
    </main>
  );
}
