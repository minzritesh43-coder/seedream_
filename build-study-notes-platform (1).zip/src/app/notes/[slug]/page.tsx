import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, CalendarDays, Eye, GraduationCap, ListTree, Timer } from "lucide-react";
import type { Metadata } from "next";
import SiteHeader from "@/components/site-header";
import SiteFooter from "@/components/site-footer";
import ReadingProgress from "@/components/reading-progress";
import NoteRenderer from "@/components/note-renderer";
import NoteActions from "@/components/note-actions";
import ViewPing from "@/components/view-ping";
import NoteCard from "@/components/note-card";
import SubjectChip from "@/components/subject-chip";
import Reveal from "@/components/reveal";
import { getNoteBySlug, getRelatedNotes, getSubjectsWithCounts } from "@/lib/queries";

export const dynamic = "force-dynamic";

const dateFmt = new Intl.DateTimeFormat("en-GB", {
  day: "numeric",
  month: "short",
  year: "numeric",
});

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const note = await getNoteBySlug(slug);
  if (!note) return { title: "Note not found" };
  return { title: note.title, description: note.excerpt };
}

export default async function NotePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const note = await getNoteBySlug(slug);
  if (!note) notFound();

  const [related, subjects] = await Promise.all([
    getRelatedNotes(note.id, note.subjectDbId),
    getSubjectsWithCounts(),
  ]);

  const toc = note.blocks
    .map((b, i) => (b.type === "heading" ? { i, text: b.text } : null))
    .filter(Boolean) as { i: number; text: string }[];

  return (
    <main className="min-h-screen">
      <SiteHeader />
      <ReadingProgress color={note.subject.color} />
      <ViewPing slug={note.slug} />

      {/* ——— article masthead ——— */}
      <article>
        <header className="border-b border-ink/60">
          <div className="mx-auto max-w-7xl px-5 pt-28 md:px-8 md:pt-36">
            <Reveal>
              <Link
                href="/notes"
                className="inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-fog transition-colors hover:text-ink"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
                Back to the archive
              </Link>
              <div className="mt-7 flex flex-wrap items-center gap-2.5">
                <SubjectChip {...note.subject} />
                <span className="inline-flex items-center gap-1.5 rounded-full border border-ink/40 px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-soot">
                  <GraduationCap className="h-3.5 w-3.5" />
                  {note.grade}
                </span>
                {note.featured && (
                  <span className="rounded-full bg-vermilion px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-paper">
                    Pinned
                  </span>
                )}
              </div>
            </Reveal>

            <Reveal delay={0.08}>
              <h1 className="mt-7 max-w-4xl font-serif text-[clamp(2.4rem,5.6vw,4.8rem)] font-semibold leading-[1.03] tracking-tight">
                {note.title}
              </h1>
            </Reveal>

            <Reveal delay={0.14}>
              <p className="dropcap mt-7 max-w-2xl text-[1.15rem] leading-[1.8] text-soot">
                {note.excerpt}
              </p>
            </Reveal>

            <Reveal delay={0.2} className="mt-9 flex flex-wrap items-center justify-between gap-5 border-t border-ink/20 py-5 pb-8">
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2 font-mono text-[10px] uppercase tracking-[0.16em] text-fog">
                <span className="text-ink">
                  Written by <span className="font-semibold">{note.author}</span>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <CalendarDays className="h-3.5 w-3.5" />
                  {dateFmt.format(note.createdAt)}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Timer className="h-3.5 w-3.5" />
                  {note.readMinutes} min read
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Eye className="h-3.5 w-3.5" />
                  {note.views} reads
                </span>
              </div>
              <NoteActions slug={note.slug} />
            </Reveal>
          </div>
        </header>

        {/* ——— body + margin ——— */}
        <div className="mx-auto grid max-w-7xl gap-14 px-5 py-14 md:px-8 lg:grid-cols-[1fr_290px]">
          <div className="min-w-0">
            <NoteRenderer blocks={note.blocks} accent={note.subject.color} />

            <div className="mt-14 border border-ink bg-cream p-7 shadow-[6px_6px_0_0_rgba(23,20,12,0.14)]">
              <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-vermilion">
                Finished reading?
              </p>
              <p className="mt-3 font-serif text-2xl font-semibold tracking-tight md:text-3xl">
                Log tonight&apos;s revision before you close the tab.
              </p>
              <div className="mt-6">
                <NoteActions slug={note.slug} variant="end" />
              </div>
            </div>
          </div>

          {/* margin rail */}
          <aside className="hidden lg:block">
            <div className="sticky top-28 flex flex-col gap-8">
              {toc.length > 0 && (
                <div>
                  <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-fog">
                    <ListTree className="h-3.5 w-3.5" />
                    In this note
                  </p>
                  <ol className="mt-4 flex flex-col gap-2.5 border-l border-ink/15 pl-4">
                    {toc.map((t, j) => (
                      <li key={t.i}>
                        <a
                          href={`#sec-${j + 1}`}
                          className="text-sm leading-snug text-soot/80 transition-colors hover:text-vermilion"
                        >
                          {t.text}
                        </a>
                      </li>
                    ))}
                  </ol>
                </div>
              )}

              <div
                className="border border-ink p-6"
                style={{ backgroundColor: `color-mix(in srgb, ${note.subject.color} 9%, #fdfaF4)` }}
              >
                <SubjectChip {...note.subject} size="sm" />
                <p className="mt-4 text-sm leading-relaxed text-soot">{note.subject.blurb}</p>
                <Link
                  href={`/subjects/${note.subject.slug}`}
                  className="group mt-4 inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-ink"
                >
                  <span className="link-line">More on this shelf</span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </div>
            </div>
          </aside>
        </div>

        {/* ——— related ——— */}
        {related.length > 0 && (
          <section className="border-t border-ink/60 bg-cream/40">
            <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
              <Reveal className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <p className="font-mono text-[11px] uppercase tracking-[0.26em] text-vermilion">
                    Keep revising
                  </p>
                  <h2 className="mt-2 font-serif text-3xl font-semibold tracking-tight md:text-4xl">
                    Also on the {note.subject.name} shelf
                  </h2>
                </div>
                <Link
                  href={`/subjects/${note.subject.slug}`}
                  className="link-line font-mono text-[10px] uppercase tracking-[0.18em] text-soot"
                >
                  View all →
                </Link>
              </Reveal>
              <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {related.map((n, i) => (
                  <Reveal key={n.slug} delay={i * 0.07}>
                    <NoteCard note={n} index={i} />
                  </Reveal>
                ))}
              </div>
            </div>
          </section>
        )}
      </article>

      <SiteFooter subjects={subjects} />
    </main>
  );
}
