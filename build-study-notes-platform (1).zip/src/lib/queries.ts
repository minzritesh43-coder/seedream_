import { and, count, desc, eq, ilike, ne, or } from "drizzle-orm";
import { db } from "@/db";
import { notes, subjects } from "@/db/schema";
import type { Block } from "./blocks";

export type SubjectInfo = {
  slug: string;
  name: string;
  color: string;
  ink: string;
  blurb: string;
  noteCount?: number;
};

export type NoteListItem = {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  author: string;
  grade: string;
  readMinutes: number;
  views: number;
  featured: boolean;
  createdAt: Date;
  subject: SubjectInfo;
};

function toListItem(row: {
  notes: typeof notes.$inferSelect;
  subjects: typeof subjects.$inferSelect;
}): NoteListItem {
  return {
    id: row.notes.id,
    slug: row.notes.slug,
    title: row.notes.title,
    excerpt: row.notes.excerpt,
    author: row.notes.author,
    grade: row.notes.grade,
    readMinutes: row.notes.readMinutes,
    views: row.notes.views,
    featured: row.notes.featured,
    createdAt: row.notes.createdAt,
    subject: {
      slug: row.subjects.slug,
      name: row.subjects.name,
      color: row.subjects.color,
      ink: row.subjects.ink,
      blurb: row.subjects.blurb,
    },
  };
}

export async function getNotes(options?: {
  subjectSlug?: string;
  query?: string;
  featuredOnly?: boolean;
  limit?: number;
}): Promise<NoteListItem[]> {
  const conditions = [];
  if (options?.subjectSlug) {
    conditions.push(eq(subjects.slug, options.subjectSlug));
  }
  if (options?.featuredOnly) {
    conditions.push(eq(notes.featured, true));
  }
  if (options?.query) {
    const like = `%${options.query.trim()}%`;
    const byText = or(ilike(notes.title, like), ilike(notes.excerpt, like), ilike(notes.author, like));
    if (byText) conditions.push(byText);
  }

  const rows = await db
    .select()
    .from(notes)
    .innerJoin(subjects, eq(notes.subjectId, subjects.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(notes.createdAt))
    .limit(options?.limit ?? 100);

  return rows.map(toListItem);
}

export type FullNote = NoteListItem & { blocks: Block[]; subjectDbId: number };

export async function getNoteBySlug(slug: string): Promise<FullNote | null> {
  const rows = await db
    .select()
    .from(notes)
    .innerJoin(subjects, eq(notes.subjectId, subjects.id))
    .where(eq(notes.slug, slug))
    .limit(1);
  if (!rows.length) return null;
  return {
    ...toListItem(rows[0]),
    blocks: rows[0].notes.blocks as Block[],
    subjectDbId: rows[0].notes.subjectId,
  };
}

export async function getRelatedNotes(noteId: number, subjectId: number, limit = 3) {
  const rows = await db
    .select()
    .from(notes)
    .innerJoin(subjects, eq(notes.subjectId, subjects.id))
    .where(and(ne(notes.id, noteId), eq(notes.subjectId, subjectId)))
    .orderBy(desc(notes.views))
    .limit(limit);
  return rows.map(toListItem);
}

export async function getSubjectsWithCounts(): Promise<SubjectInfo[]> {
  const rows = await db
    .select({ subject: subjects, noteCount: count(notes.id) })
    .from(subjects)
    .leftJoin(notes, eq(notes.subjectId, subjects.id))
    .groupBy(subjects.id)
    .orderBy(subjects.name);
  return rows.map((r) => ({
    slug: r.subject.slug,
    name: r.subject.name,
    color: r.subject.color,
    ink: r.subject.ink,
    blurb: r.subject.blurb,
    noteCount: r.noteCount,
  }));
}

export async function getLibraryStats() {
  const [noteRow] = await db.select({ value: count(notes.id) }).from(notes);
  const [subjectRow] = await db.select({ value: count(subjects.id) }).from(subjects);
  const allNotes = await db.select({ views: notes.views, readMinutes: notes.readMinutes }).from(notes);
  const totalViews = allNotes.reduce((sum, n) => sum + n.views, 0);
  const totalMinutes = allNotes.reduce((sum, n) => sum + n.readMinutes, 0);
  const authors = await db.select({ author: notes.author }).from(notes);
  const authorCount = new Set(authors.map((a) => a.author)).size;
  return {
    noteCount: noteRow?.value ?? 0,
    subjectCount: subjectRow?.value ?? 0,
    totalViews,
    totalMinutes,
    authorCount,
  };
}
