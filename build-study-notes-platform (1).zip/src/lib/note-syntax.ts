import type { Block } from "./blocks";

/**
 * Notebook syntax — a tiny line-based format used by the /write editor.
 *
 *   ## Heading
 *   plain line -> paragraph
 *   - item           -> bullet list (consecutive lines grouped)
 *   1. item          -> numbered list
 *   !key Title :: text  (also !tip, !warn)
 *   $$ formula :: caption
 *   > quote text :: attribution
 *   ::eg Title  followed by  = step  lines
 *   | A | B |     -> table row (first row is the header)
 *   ---           -> divider
 */
export function parseNotebookSyntax(source: string): Block[] {
  const lines = source.split(/\r?\n/);
  const blocks: Block[] = [];
  let i = 0;

  while (i < lines.length) {
    const raw = lines[i];
    const line = raw.trim();

    if (!line) {
      i++;
      continue;
    }

    if (line === "---") {
      blocks.push({ type: "divider" });
      i++;
      continue;
    }

    if (line.startsWith("## ")) {
      blocks.push({ type: "heading", text: line.slice(3).trim() });
      i++;
      continue;
    }

    if (line.startsWith("$$")) {
      const rest = line.slice(2).trim();
      const [math, label] = splitOnce(rest, "::");
      blocks.push({ type: "formula", math: math.trim(), label: label?.trim() || undefined });
      i++;
      continue;
    }

    if (line.startsWith("!key") || line.startsWith("!tip") || line.startsWith("!warn")) {
      const variant = line.startsWith("!key") ? "key" : line.startsWith("!tip") ? "tip" : "warn";
      const rest = line.slice(4).trim();
      const [head, ...tail] = rest.split("::");
      if (tail.length) {
        blocks.push({
          type: "callout",
          variant,
          title: head.trim() || undefined,
          text: tail.join("::").trim(),
        });
      } else {
        blocks.push({ type: "callout", variant, text: head.trim() });
      }
      i++;
      continue;
    }

    if (line.startsWith("::eg")) {
      const title = line.slice(4).trim() || "Worked example";
      const steps: string[] = [];
      i++;
      while (i < lines.length && lines[i].trim().startsWith("= ")) {
        steps.push(lines[i].trim().slice(2).trim());
        i++;
      }
      if (steps.length) {
        blocks.push({ type: "example", title, steps });
      } else {
        blocks.push({ type: "callout", variant: "tip", title, text: "" });
      }
      continue;
    }

    if (line.startsWith(">")) {
      const rest = line.slice(1).trim();
      const [text, cite] = splitOnce(rest, "::");
      blocks.push({ type: "quote", text: text.trim(), cite: cite?.trim() || undefined });
      i++;
      continue;
    }

    if (line.startsWith("|")) {
      const rows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) {
        const cells = lines[i]
          .trim()
          .replace(/^\||\|$/g, "")
          .split("|")
          .map((c) => c.trim());
        rows.push(cells);
        i++;
      }
      const head = rows.shift() ?? [];
      blocks.push({ type: "table", head, rows });
      continue;
    }

    if (line.startsWith("- ")) {
      const items: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith("- ")) {
        items.push(lines[i].trim().slice(2).trim());
        i++;
      }
      blocks.push({ type: "list", items });
      continue;
    }

    if (/^\d+\.\s/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+\.\s/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^\d+\.\s/, ""));
        i++;
      }
      blocks.push({ type: "list", items, ordered: true });
      continue;
    }

    blocks.push({ type: "paragraph", text: line });
    i++;
  }

  return blocks;
}

function splitOnce(s: string, sep: string): [string, string | undefined] {
  const idx = s.indexOf(sep);
  if (idx === -1) return [s, undefined];
  return [s.slice(0, idx), s.slice(idx + sep.length)];
}

export function slugify(title: string): string {
  const base = title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 80);
  return base || "untitled-note";
}

export function estimateMinutes(blocks: Block[]): { minutes: number; words: number } {
  let words = 0;
  const walk = (t: { type: Block["type"] } & Record<string, unknown>) => {
    const count = (s: unknown) => {
      if (typeof s === "string") words += s.split(/\s+/).filter(Boolean).length;
    };
    count(t.text);
    count(t.title);
    count(t.math);
    count(t.cite);
    if (Array.isArray(t.items)) (t.items as string[]).forEach(count);
    if (Array.isArray(t.steps)) (t.steps as string[]).forEach(count);
    if (Array.isArray(t.head)) (t.head as string[]).forEach(count);
    if (Array.isArray(t.rows)) (t.rows as string[][]).flat().forEach(count);
  };
  blocks.forEach((blk) => walk(blk as never));
  return { minutes: Math.max(1, Math.round(words / 180)), words };
}
