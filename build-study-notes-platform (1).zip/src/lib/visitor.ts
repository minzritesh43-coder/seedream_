export function getVisitorId(): string {
  if (typeof window === "undefined") return "";
  let id = window.localStorage.getItem("commonplace-visitor");
  if (!id) {
    id =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `v-${Math.random().toString(36).slice(2)}-${Date.now().toString(36)}`;
    window.localStorage.setItem("commonplace-visitor", id);
  }
  return id;
}
