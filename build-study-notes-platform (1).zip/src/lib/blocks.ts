export type Block =
  | { type: "heading"; text: string }
  | { type: "paragraph"; text: string }
  | { type: "list"; items: string[]; ordered?: boolean }
  | { type: "callout"; variant: "key" | "tip" | "warn"; title?: string; text: string }
  | { type: "formula"; math: string; label?: string }
  | { type: "quote"; text: string; cite?: string }
  | { type: "example"; title: string; steps: string[] }
  | { type: "table"; head: string[]; rows: string[][] }
  | { type: "divider" };

export const h2 = (text: string): Block => ({ type: "heading", text });
export const p = (text: string): Block => ({ type: "paragraph", text });
export const ul = (items: string[]): Block => ({ type: "list", items });
export const ol = (items: string[]): Block => ({ type: "list", items, ordered: true });
export const callout = (variant: "key" | "tip" | "warn", title: string, text: string): Block => ({
  type: "callout",
  variant,
  title,
  text,
});
export const formula = (math: string, label?: string): Block => ({ type: "formula", math, label });
export const quote = (text: string, cite?: string): Block => ({ type: "quote", text, cite });
export const example = (title: string, steps: string[]): Block => ({ type: "example", title, steps });
export const table = (head: string[], rows: string[][]): Block => ({ type: "table", head, rows });
export const divider = (): Block => ({ type: "divider" });
