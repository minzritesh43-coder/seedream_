import Link from "next/link";
import { ArrowUpRight, Eye, Timer } from "lucide-react";
import type { NoteListItem } from "@/lib/queries";
import SubjectChip from "./subject-chip";

export default function NoteCard({
  note,
  index,
}: {
  note: NoteListItem;
  index?: number;
}) {
  return (
    <Link
      href={`/notes/${note.slug}`}
      className="group relative flex h-full flex-col border border-ink/80 bg-cream p-6 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[7px_7px_0_0_#17140c] md:p-7"
    >
      <div className="flex items-center justify-between gap-3">
        <SubjectChip {...note.subject} size="sm" asLink={false} />
        {typeof index === "number" && (
          <span className="font-mono text-[11px] tracking-[0.2em] text-fog">
            N°{String(index + 1).padStart(2, "0")}
          </span>
        )}
      </div>

      <h3 className="mt-5 font-serif text-[1.55rem] font-semibold leading-[1.12] tracking-tight transition-colors duration-300 group-hover:text-vermilion-deep md:text-[1.7rem]">
        {note.title}
      </h3>

      <p className="mt-3 line-clamp-3 text-[15px] leading-relaxed text-soot/90">
        {note.excerpt}
      </p>

      <div className="mt-auto flex items-center justify-between gap-3 pt-6">
        <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.14em] text-fog">
          <span>{note.author.split(" ")[0]}</span>
          <span className="inline-flex items-center gap-1">
            <Timer className="h-3 w-3" />
            {note.readMinutes} min
          </span>
          <span className="hidden items-center gap-1 sm:inline-flex">
            <Eye className="h-3 w-3" />
            {note.views}
          </span>
        </div>
        <span className="flex h-8 w-8 items-center justify-center rounded-full border border-ink/30 transition-all duration-300 group-hover:border-ink group-hover:bg-ink group-hover:text-paper">
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:rotate-45" />
        </span>
      </div>
    </Link>
  );
}
