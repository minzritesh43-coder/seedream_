"use client";

import { useEffect, useState } from "react";
import { Bookmark, Check, Link2, Repeat2 } from "lucide-react";
import clsx from "clsx";
import { getVisitorId } from "@/lib/visitor";

export default function NoteActions({
  slug,
  variant = "bar",
}: {
  slug: string;
  variant?: "bar" | "end";
}) {
  const [saved, setSaved] = useState(false);
  const [busySave, setBusySave] = useState(false);
  const [revised, setRevised] = useState(false);
  const [busyRevise, setBusyRevise] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const visitor = getVisitorId();
    fetch(`/api/notes/${slug}/bookmark?visitor=${encodeURIComponent(visitor)}`)
      .then((r) => r.json())
      .then((d) => setSaved(Boolean(d.saved)))
      .catch(() => {});
    const revisedKey = `revised:${slug}:${new Date().toDateString()}`;
    if (window.localStorage.getItem(revisedKey)) setRevised(true);
  }, [slug]);

  const toggleSave = async () => {
    if (busySave) return;
    setBusySave(true);
    const optimistic = !saved;
    setSaved(optimistic);
    try {
      const res = await fetch(`/api/notes/${slug}/bookmark`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ visitorId: getVisitorId() }),
      });
      const data = await res.json();
      setSaved(Boolean(data.saved));
    } catch {
      setSaved(!optimistic);
    } finally {
      setBusySave(false);
    }
  };

  const markRevised = async () => {
    if (busyRevise || revised) return;
    setBusyRevise(true);
    try {
      const res = await fetch(`/api/notes/${slug}/revise`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ visitorId: getVisitorId() }),
      });
      if (res.ok) {
        setRevised(true);
        const revisedKey = `revised:${slug}:${new Date().toDateString()}`;
        window.localStorage.setItem(revisedKey, "1");
      }
    } catch {
      /* silent */
    } finally {
      setBusyRevise(false);
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* silent */
    }
  };

  const base =
    "inline-flex items-center gap-2 rounded-full border px-4 py-2 font-mono uppercase transition-all duration-300";
  const sizeClasses = variant === "bar" ? "text-[10px] tracking-[0.14em]" : "text-[11px] px-5 py-2.5 tracking-[0.16em]";

  return (
    <div className="flex flex-wrap items-center gap-2.5">
      <button
        onClick={toggleSave}
        className={clsx(
          base,
          sizeClasses,
          saved
            ? "border-ink bg-ink text-paper"
            : "border-ink/40 text-soot hover:border-ink hover:bg-ink hover:text-paper",
        )}
      >
        <Bookmark className={clsx("h-3.5 w-3.5", saved && "fill-vermilion text-vermilion")} />
        {saved ? "On your shelf" : "Save for revision"}
      </button>

      <button
        onClick={markRevised}
        disabled={revised}
        className={clsx(
          base,
          sizeClasses,
          revised
            ? "cursor-default border-vermilion bg-vermilion text-paper"
            : "border-ink/40 text-soot hover:border-vermilion hover:bg-vermilion hover:text-paper",
        )}
      >
        {revised ? <Check className="h-3.5 w-3.5" /> : <Repeat2 className="h-3.5 w-3.5" />}
        {revised ? "Revised today" : "Mark as revised"}
      </button>

      <button
        onClick={copyLink}
        className={clsx(base, sizeClasses, "border-ink/40 text-soot hover:border-ink hover:bg-ink hover:text-paper")}
      >
        {copied ? <Check className="h-3.5 w-3.5" /> : <Link2 className="h-3.5 w-3.5" />}
        {copied ? "Copied" : "Copy link"}
      </button>
    </div>
  );
}
