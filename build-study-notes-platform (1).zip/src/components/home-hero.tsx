"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, ArrowRight, Sparkles } from "lucide-react";

type Stat = { value: number; label: string; suffix?: string };
type SubjectLite = { name: string; color: string };

const ease = [0.22, 1, 0.36, 1] as const;

function HeadlineLine({ children, delay }: { children: React.ReactNode; delay: number }) {
  return (
    <span className="block overflow-hidden pb-1">
      <motion.span
        className="block"
        initial={{ y: "110%" }}
        animate={{ y: "0%" }}
        transition={{ duration: 0.9, delay, ease }}
      >
        {children}
      </motion.span>
    </span>
  );
}

export default function HomeHero({
  stats,
  subjects,
}: {
  stats: Stat[];
  subjects: SubjectLite[];
}) {
  const [wordIdx, setWordIdx] = useState(0);

  useEffect(() => {
    if (!subjects.length) return;
    const t = setInterval(() => setWordIdx((v) => (v + 1) % subjects.length), 2200);
    return () => clearInterval(t);
  }, [subjects.length]);

  const current = subjects[wordIdx] ?? { name: "everything", color: "#e4572e" };

  return (
    <section className="rule-lines relative overflow-hidden border-b border-ink/60 px-5 pt-28 md:px-8 md:pt-36">
      <div className="mx-auto grid max-w-7xl gap-14 pb-14 md:pb-20 lg:grid-cols-[1.5fr_1fr] lg:gap-8">
        {/* left — words */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15, ease }}
            className="flex flex-wrap items-center gap-3 font-mono text-[11px] uppercase tracking-[0.24em] text-soot"
          >
            <Sparkles className="h-3.5 w-3.5 text-vermilion" />
            <span>Notes on</span>
            <span className="relative inline-flex h-6 min-w-36 items-center overflow-hidden rounded-full border border-ink/50 px-3">
              <AnimatePresence mode="wait">
                <motion.span
                  key={current.name}
                  initial={{ y: 14, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -14, opacity: 0 }}
                  transition={{ duration: 0.4, ease }}
                  style={{ color: current.color }}
                  className="font-semibold"
                >
                  {current.name}
                </motion.span>
              </AnimatePresence>
            </span>
            <span className="hidden text-fog sm:inline">· written by classmates, for classmates</span>
          </motion.div>

          <h1 className="mt-8 font-serif text-[clamp(3.2rem,9.2vw,8.2rem)] font-semibold leading-[0.95] tracking-[-0.02em] text-ink">
            <HeadlineLine delay={0.25}>Write it down.</HeadlineLine>
            <HeadlineLine delay={0.38}>Share it out.</HeadlineLine>
            <HeadlineLine delay={0.51}>
              Revise it{" "}
              <span className="relative inline-block italic text-vermilion">
                forever.
                <svg
                  viewBox="0 0 220 14"
                  className="absolute -bottom-3 left-0 w-full"
                  aria-hidden
                >
                  <motion.path
                    d="M4 10 C 60 2, 160 2, 216 8"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="5"
                    strokeLinecap="round"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 0.8, delay: 1.25, ease }}
                  />
                </svg>
              </span>
            </HeadlineLine>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.85, ease }}
            className="mt-9 max-w-xl text-lg leading-relaxed text-soot"
          >
            Commonplace is the class&apos;s shared notebook. One student&apos;s
            evening of tidy notes becomes everyone&apos;s calmer revision — and
            explaining something remains the sharpest way to actually learn it.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1, ease }}
            className="mt-9 flex flex-wrap items-center gap-5"
          >
            <Link
              href="/notes"
              className="group inline-flex items-center gap-2.5 rounded-full border border-ink bg-ink px-7 py-3.5 font-mono text-[11px] uppercase tracking-[0.16em] text-paper transition-all duration-300 hover:bg-vermilion hover:shadow-[4px_4px_0_0_#17140c]"
            >
              Open the notebook
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
            <Link
              href="/write"
              className="link-line font-mono text-[11px] uppercase tracking-[0.16em] text-soot"
            >
              Write tonight&apos;s note →
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.15 }}
            className="mt-14 grid max-w-xl grid-cols-2 gap-6 border-t border-ink/60 pt-6 sm:grid-cols-4"
          >
            {stats.map((s) => (
              <div key={s.label}>
                <p className="font-mono text-2xl font-medium tracking-tight text-ink md:text-[1.7rem]">
                  {s.value}
                  {s.suffix ?? ""}
                </p>
                <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.2em] text-fog">
                  {s.label}
                </p>
              </div>
            ))}
          </motion.div>
        </div>

        {/* right — the paper stack */}
        <div className="relative hidden lg:block" aria-hidden>
          <motion.div
            initial={{ opacity: 0, y: 40, rotate: 6 }}
            animate={{ opacity: 1, y: 0, rotate: 5 }}
            transition={{ duration: 1, delay: 0.7, ease }}
            className="absolute right-6 top-10 w-64 border border-ink/50 bg-paper p-5 shadow-[8px_8px_0_0_rgba(23,20,12,0.14)]"
          >
            <div className="absolute -top-3 left-1/2 h-6 w-20 -translate-x-1/2 rotate-[-4deg] bg-[#e9dfc6]/90 shadow-sm" />
            <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-[#7148d6]">Physics</p>
            <p className="mt-2 font-serif text-xl font-semibold leading-tight">Newton&apos;s Laws of Motion</p>
            <div className="mt-4 space-y-2.5">
              {[92, 100, 78, 95, 60].map((w, i) => (
                <div key={i} className="h-[3px] rounded bg-ink/12" style={{ width: `${w}%` }} />
              ))}
            </div>
            <p className="mt-4 font-mono text-[9px] uppercase tracking-[0.18em] text-fog">
              7 min · 412 reads
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 56, rotate: -7 }}
            animate={{ opacity: 1, y: 0, rotate: -6 }}
            transition={{ duration: 1, delay: 0.9, ease }}
            className="absolute bottom-4 left-0 w-60 border border-ink/50 bg-cream p-5 shadow-[8px_8px_0_0_rgba(23,20,12,0.14)]"
          >
            <div className="absolute -top-2.5 right-6 h-5 w-16 rotate-[8deg] bg-[#e9dfc6]/90 shadow-sm" />
            <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-[#d6336c]">Computer Science</p>
            <p className="mt-2 font-serif text-xl font-semibold leading-tight">Big-O, Without the Fear</p>
            <div className="mt-4 space-y-2.5">
              {[100, 84, 92, 70].map((w, i) => (
                <div key={i} className="h-[3px] rounded bg-ink/12" style={{ width: `${w}%` }} />
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 1.25, ease }}
            className="absolute right-2 bottom-40 rotate-3 border border-ink bg-vermilion px-4 py-2 font-mono text-[9px] uppercase tracking-[0.22em] text-paper shadow-[4px_4px_0_0_#17140c]"
          >
            updated nightly
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 0.8 }}
        className="mx-auto flex max-w-7xl items-center gap-2 pb-6 font-mono text-[10px] uppercase tracking-[0.24em] text-fog"
      >
        <ArrowDown className="h-3.5 w-3.5 animate-pulse-soft" />
        Scroll the shelves
      </motion.div>
    </section>
  );
}
