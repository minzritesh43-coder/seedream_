import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import type { SubjectInfo } from "@/lib/queries";

export type SubjectIndexRow = SubjectInfo & {
  latestTitle?: string;
};

export default function SubjectIndex({ rows }: { rows: SubjectIndexRow[] }) {
  return (
    <div className="border-y border-ink/60">
      {rows.map((s, i) => (
        <Link
          key={s.slug}
          href={`/subjects/${s.slug}`}
          style={{ "--row": s.color, "--rowink": s.ink } as React.CSSProperties}
          className="group block border-b border-ink/20 transition-colors duration-300 last:border-b-0 hover:bg-(--row)"
        >
          <div className="mx-auto grid max-w-7xl grid-cols-[2.6rem_1fr_auto] items-baseline gap-x-4 px-5 py-6 md:grid-cols-[4rem_1.3fr_1.5fr_auto_2.5rem] md:gap-x-8 md:px-8 md:py-8">
            <span className="font-mono text-xs tracking-[0.2em] text-fog transition-colors duration-300 group-hover:text-(--rowink) group-hover:opacity-60">
              {String(i + 1).padStart(2, "0")}
            </span>

            <h3 className="truncate font-serif text-2xl font-semibold tracking-tight text-ink transition-all duration-300 group-hover:translate-x-2 group-hover:text-(--rowink) md:text-4xl">
              {s.name}
            </h3>

            <p className="hidden max-w-md text-sm leading-relaxed text-soot/85 transition-colors duration-300 group-hover:text-(--rowink) group-hover:opacity-85 md:block">
              {s.blurb}
              {s.latestTitle && (
                <span className="mt-1 block font-mono text-[9px] uppercase tracking-[0.2em] opacity-60">
                  Newest — {s.latestTitle}
                </span>
              )}
            </p>

            <span className="justify-self-end whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.18em] text-fog transition-colors duration-300 group-hover:text-(--rowink) group-hover:opacity-70">
              {s.noteCount ?? 0} {(s.noteCount ?? 0) === 1 ? "note" : "notes"}
            </span>

            <ArrowUpRight className="hidden h-5 w-5 justify-self-end text-fog transition-all duration-300 group-hover:rotate-45 group-hover:text-(--rowink) md:block" />
          </div>
        </Link>
      ))}
    </div>
  );
}
