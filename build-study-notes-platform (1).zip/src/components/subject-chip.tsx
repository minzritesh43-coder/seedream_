import Link from "next/link";
import clsx from "clsx";

export default function SubjectChip({
  slug,
  name,
  color,
  ink,
  asLink = true,
  size = "md",
}: {
  slug: string;
  name: string;
  color: string;
  ink: string;
  asLink?: boolean;
  size?: "sm" | "md";
}) {
  const inner = (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 rounded-full font-mono uppercase tracking-[0.14em] transition-transform duration-300",
        size === "sm" ? "px-2.5 py-1 text-[9px]" : "px-3.5 py-1.5 text-[10px]",
        asLink && "hover:-translate-y-0.5",
      )}
      style={{ backgroundColor: color, color: ink }}
    >
      <span
        className="h-1.5 w-1.5 rounded-full"
        style={{ backgroundColor: ink === "#17140c" ? "#17140c" : "currentColor", opacity: 0.85 }}
      />
      {name}
    </span>
  );
  if (!asLink) return inner;
  return <Link href={`/subjects/${slug}`}>{inner}</Link>;
}
