import Link from "next/link";
import type { SubjectInfo } from "@/lib/queries";

export default function SiteFooter({ subjects }: { subjects: SubjectInfo[] }) {
  return (
    <footer className="relative overflow-hidden border-t border-ink bg-ink text-paper">
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-16 md:px-8">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-paper/50">
              The colophon
            </p>
            <p className="mt-4 max-w-md font-serif text-xl leading-relaxed text-paper/85 md:text-2xl">
              Commonplace is a shared notebook — every explanation a classmate
              writes makes the whole class a little sharper.
            </p>
            <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.2em] text-paper/45">
              Written between classes · Set in Fraunces & Instrument Sans
            </p>
          </div>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-paper/50">
              Shelves
            </p>
            <ul className="mt-4 space-y-2.5">
              {subjects.slice(0, 8).map((s) => (
                <li key={s.slug}>
                  <Link
                    href={`/subjects/${s.slug}`}
                    className="group inline-flex items-center gap-2 text-sm text-paper/80 transition-colors hover:text-paper"
                  >
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: s.color }}
                    />
                    <span className="link-line">{s.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.25em] text-paper/50">
              The notebook
            </p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper/80">
              <li>
                <Link href="/notes" className="link-line">
                  Browse all notes
                </Link>
              </li>
              <li>
                <Link href="/write" className="link-line">
                  Write tonight&apos;s note
                </Link>
              </li>
              <li>
                <Link href="/revise" className="link-line">
                  Tonight&apos;s revision shelf
                </Link>
              </li>
              <li>
                <Link href="/#manifesto" className="link-line">
                  The manifesto
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 select-none overflow-hidden leading-none">
          <p className="u-outline-paper whitespace-nowrap font-serif text-[18vw] font-black italic tracking-tight md:text-[13vw]">
            Commonplace
          </p>
        </div>

        <div className="mt-8 flex flex-col items-start justify-between gap-3 border-t border-paper/15 pt-6 font-mono text-[10px] uppercase tracking-[0.2em] text-paper/40 sm:flex-row sm:items-center">
          <span>© {new Date().getFullYear()} The class notebook</span>
          <span>Revise · Share · Repeat</span>
        </div>
      </div>
    </footer>
  );
}
