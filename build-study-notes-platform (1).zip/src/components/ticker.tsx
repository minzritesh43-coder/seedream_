import { Asterisk } from "lucide-react";
import type { SubjectInfo } from "@/lib/queries";

export default function Ticker({
  subjects,
  invert = false,
  slow = false,
}: {
  subjects: SubjectInfo[];
  invert?: boolean;
  slow?: boolean;
}) {
  const items = [...subjects, ...subjects];
  const row = (key: string) => (
    <div key={key} className="flex w-max shrink-0 items-center">
      {items.map((s, i) => (
        <span
          key={`${key}-${i}`}
          className="flex items-center gap-3 px-5 font-mono text-[11px] uppercase tracking-[0.28em]"
        >
          <span style={{ color: invert ? s.color : undefined }}>{s.name}</span>
          <Asterisk className="h-3.5 w-3.5 opacity-50" />
        </span>
      ))}
    </div>
  );

  return (
    <div
      className={
        invert
          ? "relative overflow-hidden border-y border-ink/60 bg-paper py-3 text-ink"
          : "relative overflow-hidden border-y border-ink bg-ink py-3 text-paper"
      }
    >
      <div className={`flex w-max ${slow ? "animate-marquee-slow" : "animate-marquee"}`}>
        {row("a")}
        {row("b")}
      </div>
    </div>
  );
}
