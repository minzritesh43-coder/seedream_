"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { PenLine, Repeat2 } from "lucide-react";
import clsx from "clsx";

const links = [
  { href: "/notes", label: "All notes" },
  { href: "/revise", label: "My revision" },
];

export default function SiteHeader() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -64, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className={clsx(
        "fixed inset-x-0 top-0 z-50 border-b transition-all duration-500",
        scrolled
          ? "border-ink/15 bg-paper/90 backdrop-blur-md"
          : "border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 md:px-8">
        <Link href="/" className="group flex items-baseline gap-2" aria-label="Commonplace home">
          <span className="font-serif text-[22px] font-semibold italic tracking-tight">
            Commonplace
          </span>
          <span className="mb-0.5 h-2 w-2 rounded-full bg-vermilion transition-transform duration-300 group-hover:scale-150" />
          <span className="hidden font-mono text-[10px] uppercase tracking-[0.22em] text-fog sm:inline">
            Vol.01
          </span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={clsx(
                "rounded-full px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] transition-colors sm:px-4",
                pathname === l.href
                  ? "bg-ink text-paper"
                  : "text-soot hover:bg-ink/8",
              )}
            >
              {l.label === "My revision" ? (
                <span className="flex items-center gap-1.5">
                  <Repeat2 className="h-3 w-3" />
                  <span className="hidden sm:inline">{l.label}</span>
                  <span className="sm:hidden">Revise</span>
                </span>
              ) : (
                l.label
              )}
            </Link>
          ))}
          <Link
            href="/write"
            className="group ml-1 flex items-center gap-2 rounded-full border border-ink bg-vermilion px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-paper shadow-[3px_3px_0_0_#17140c] transition-all duration-300 hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0_0_#17140c] sm:px-5"
          >
            <PenLine className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-rotate-12" />
            <span className="hidden sm:inline">Write a note</span>
            <span className="sm:hidden">Write</span>
          </Link>
        </nav>
      </div>
    </motion.header>
  );
}
