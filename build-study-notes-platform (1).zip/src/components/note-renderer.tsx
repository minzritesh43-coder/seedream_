"use client";

import { motion } from "framer-motion";
import { KeyRound, Lightbulb, Quote, Sigma, TriangleAlert, Wrench } from "lucide-react";
import type { CSSProperties, ReactNode } from "react";
import type { Block } from "@/lib/blocks";

/* ————————————————— inline parser ————————————————— */

const MARKERS = ["`", "**", "*", "^", "~"] as const;

function parseInline(text: string, keyPrefix: string): ReactNode[] {
  const out: ReactNode[] = [];
  let i = 0;
  let k = 0;

  while (i < text.length) {
    // find the earliest marker from position i
    let hitIdx = -1;
    let hitMarker: (typeof MARKERS)[number] | null = null;

    for (const m of MARKERS) {
      const idx = text.indexOf(m, i);
      if (idx !== -1 && (hitIdx === -1 || idx < hitIdx)) {
        hitIdx = idx;
        hitMarker = m;
      }
    }

    if (hitIdx === -1 || !hitMarker) {
      out.push(text.slice(i));
      break;
    }

    if (hitIdx > i) out.push(text.slice(i, hitIdx));

    // prefer "**" over "*" at the same spot
    let marker = hitMarker;
    if (marker === "*" && text.startsWith("**", hitIdx)) marker = "**";

    const close = text.indexOf(marker, hitIdx + marker.length);
    if (close === -1) {
      // no closing marker — render literally
      out.push(marker);
      i = hitIdx + marker.length;
      k += 1;
      continue;
    }

    const raw = text.slice(hitIdx + marker.length, close);
    const key = `${keyPrefix}-${k++}`;

    if (marker === "`") {
      out.push(
        <code
          key={key}
          className="rounded-md border border-ink/20 bg-ink/[0.055] px-1.5 py-0.5 font-mono text-[0.84em] text-ink"
        >
          {raw}
        </code>,
      );
    } else if (marker === "**") {
      out.push(
        <strong key={key} className="font-semibold text-ink">
          {raw}
        </strong>,
      );
    } else if (marker === "*") {
      out.push(
        <em key={key} className="italic">
          {raw}
        </em>,
      );
    } else if (marker === "^") {
      out.push(
        <sup key={key} className="text-[0.72em] font-medium">
          {raw}
        </sup>,
      );
    } else {
      out.push(
        <sub key={key} className="text-[0.72em] font-medium">
          {raw}
        </sub>,
      );
    }

    i = close + marker.length;
  }

  return out;
}

export function Inline({ text }: { text: string }) {
  return <>{parseInline(text, "in")}</>;
}

/* ————————————————— block wrapper ————————————————— */

function Fade({ children, i, className }: { children: ReactNode; i: number; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-30px" }}
      transition={{ duration: 0.55, delay: Math.min(i * 0.03, 0.25), ease: [0.22, 1, 0.36, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

/* ————————————————— renderer ————————————————— */

export default function NoteRenderer({
  blocks,
  accent = "#e4572e",
}: {
  blocks: Block[];
  accent?: string;
}) {
  let section = 0;

  return (
    <div className="flex flex-col gap-8">
      {blocks.map((b, i) => {
        const key = `blk-${i}`;

        switch (b.type) {
          case "heading": {
            section += 1;
            return (
              <Fade key={key} i={i}>
                <h2 id={`sec-${section}`} className="flex scroll-mt-28 items-baseline gap-4 pt-4">
                  <span className="font-mono text-[11px] tracking-[0.22em] text-vermilion">
                    {String(section).padStart(2, "0")}
                  </span>
                  <span className="font-serif text-[1.7rem] font-semibold leading-tight tracking-tight text-ink md:text-4xl">
                    <Inline text={b.text} />
                  </span>
                </h2>
                <div className="mt-4 h-px w-full bg-ink/15" />
              </Fade>
            );
          }

          case "paragraph":
            return (
              <Fade key={key} i={i}>
                <p className="max-w-[68ch] text-[1.05rem] leading-[1.85] text-soot">
                  <Inline text={b.text} />
                </p>
              </Fade>
            );

          case "list":
            return (
              <Fade key={key} i={i}>
                {b.ordered ? (
                  <ol className="flex max-w-[66ch] flex-col gap-3">
                    {b.items.map((item, j) => (
                      <li key={j} className="flex gap-4">
                        <span className="mt-[0.28rem] font-mono text-[11px] tracking-[0.1em] text-vermilion">
                          {String(j + 1).padStart(2, "0")}
                        </span>
                        <span className="text-[1.02rem] leading-[1.75] text-soot">
                          <Inline text={item} />
                        </span>
                      </li>
                    ))}
                  </ol>
                ) : (
                  <ul className="flex max-w-[66ch] flex-col gap-3">
                    {b.items.map((item, j) => (
                      <li key={j} className="flex gap-4">
                        <span
                          className="mt-[0.72rem] h-[7px] w-[7px] shrink-0 rotate-45"
                          style={{ backgroundColor: accent }}
                        />
                        <span className="text-[1.02rem] leading-[1.75] text-soot">
                          <Inline text={item} />
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </Fade>
            );

          case "callout": {
            if (b.variant === "key") {
              return (
                <Fade key={key} i={i}>
                  <div className="border border-ink bg-ink p-6 text-paper shadow-[6px_6px_0_0_rgba(23,20,12,0.18)] md:p-8">
                    <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em] text-vermilion">
                      <KeyRound className="h-3.5 w-3.5" />
                      {b.title ?? "Key idea"}
                    </p>
                    <p className="mt-3 max-w-[62ch] text-[1.02rem] leading-[1.8] text-paper/90">
                      <Inline text={b.text} />
                    </p>
                  </div>
                </Fade>
              );
            }
            const isTip = b.variant === "tip";
            return (
              <Fade key={key} i={i}>
                <div
                  className={
                    isTip
                      ? "border border-ink/70 bg-[#eef3dc] p-6 md:p-7"
                      : "border border-dashed border-vermilion-deep/70 bg-[#fbe9dd] p-6 md:p-7"
                  }
                >
                  <p
                    className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.24em]"
                    style={{ color: isTip ? "#5f7a0b" : "#c2410c" }}
                  >
                    {isTip ? <Lightbulb className="h-3.5 w-3.5" /> : <TriangleAlert className="h-3.5 w-3.5" />}
                    {b.title ?? (isTip ? "Tip" : "Watch out")}
                  </p>
                  <p className="mt-3 max-w-[62ch] text-[1rem] leading-[1.8] text-soot">
                    <Inline text={b.text} />
                  </p>
                </div>
              </Fade>
            );
          }

          case "formula":
            return (
              <Fade key={key} i={i}>
                <figure className="relative overflow-hidden border border-ink/80 bg-cream px-6 py-8 text-center md:py-10">
                  <Sigma
                    className="absolute left-4 top-4 h-4 w-4"
                    style={{ color: accent }}
                  />
                  <div className="dot-grid absolute inset-0 opacity-40" />
                  <div className="relative">
                    <p className="font-serif text-2xl italic leading-snug tracking-tight text-ink md:text-[2rem]">
                      <Inline text={b.math} />
                    </p>
                    {b.label && (
                      <figcaption className="mt-3 font-mono text-[10px] uppercase tracking-[0.24em] text-fog">
                        {b.label}
                      </figcaption>
                    )}
                  </div>
                </figure>
              </Fade>
            );

          case "quote":
            return (
              <Fade key={key} i={i}>
                <figure className="relative pl-10 md:pl-14">
                  <Quote className="absolute left-0 top-1 h-6 w-6 rotate-180 text-vermilion" />
                  <blockquote className="max-w-[60ch] font-serif text-xl italic leading-relaxed text-ink md:text-[1.55rem]">
                    <Inline text={b.text} />
                  </blockquote>
                  {b.cite && (
                    <figcaption className="mt-3 font-mono text-[10px] uppercase tracking-[0.22em] text-fog">
                      — {b.cite}
                    </figcaption>
                  )}
                </figure>
              </Fade>
            );

          case "example":
            return (
              <Fade key={key} i={i}>
                <div className="border border-ink/70 bg-paper shadow-[6px_6px_0_0_rgba(23,20,12,0.12)]">
                  <p className="inline-flex items-center gap-2 border-b border-r border-ink/70 bg-ink px-4 py-2 font-mono text-[10px] uppercase tracking-[0.22em] text-paper">
                    <Wrench className="h-3.5 w-3.5 text-vermilion" />
                    {b.title}
                  </p>
                  <ol className="flex flex-col gap-3.5 p-6 md:p-8">
                    {b.steps.map((s, j) => (
                      <li key={j} className="flex gap-4">
                        <span className="mt-[0.2rem] font-mono text-[11px] tracking-[0.1em] text-vermilion">
                          {j + 1}.
                        </span>
                        <span className="text-[1rem] leading-[1.75] text-soot">
                          <Inline text={s} />
                        </span>
                      </li>
                    ))}
                  </ol>
                </div>
              </Fade>
            );

          case "table":
            return (
              <Fade key={key} i={i}>
                <div className="-mx-1 overflow-x-auto px-1 pb-2">
                  <table className="w-full min-w-[560px] border-collapse border border-ink/80 bg-cream text-left">
                    <thead>
                      <tr>
                        {b.head.map((h, j) => (
                          <th
                            key={j}
                            className="border border-ink/80 bg-ink px-4 py-2.5 font-mono text-[10px] font-medium uppercase tracking-[0.18em] text-paper"
                          >
                            <Inline text={h} />
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {b.rows.map((row, r) => (
                        <tr key={r} className="transition-colors even:bg-ink/[0.035]">
                          {row.map((cell, c) => (
                            <td
                              key={c}
                              className="border border-ink/30 px-4 py-3 text-[0.95rem] leading-relaxed text-soot"
                            >
                              <Inline text={cell} />
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Fade>
            );

          case "divider":
            return (
              <Fade key={key} i={i}>
                <div className="flex items-center gap-5 py-2" aria-hidden>
                  <span className="h-px flex-1 bg-ink/20" />
                  <span className="flex gap-1.5">
                    {[0, 1, 2].map((d) => (
                      <span
                        key={d}
                        className="h-1.5 w-1.5 rotate-45"
                        style={{ backgroundColor: d === 1 ? accent : "#17140c", opacity: d === 1 ? 1 : 0.35 } as CSSProperties}
                      />
                    ))}
                  </span>
                  <span className="h-px flex-1 bg-ink/20" />
                </div>
              </Fade>
            );

          default:
            return null;
        }
      })}
    </div>
  );
}
