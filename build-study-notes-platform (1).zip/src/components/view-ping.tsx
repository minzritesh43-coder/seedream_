"use client";

import { useEffect } from "react";

export default function ViewPing({ slug }: { slug: string }) {
  useEffect(() => {
    const key = `viewed:${slug}`;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");
    fetch(`/api/notes/${slug}/view`, { method: "POST" }).catch(() => {});
  }, [slug]);
  return null;
}
