"use client";

import { motion, useScroll, useSpring } from "framer-motion";

export default function ReadingProgress({ color = "#e4572e" }: { color?: string }) {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 140, damping: 28, mass: 0.4 });

  return (
    <motion.div
      className="fixed inset-x-0 top-16 z-40 h-[3px] origin-left"
      style={{ scaleX, backgroundColor: color }}
    />
  );
}
