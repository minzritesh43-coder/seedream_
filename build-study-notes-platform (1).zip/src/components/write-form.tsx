"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { CircleAlert, Eye, LoaderCircle, PenLine, Send } from "lucide-react";
import clsx from "clsx";
import type { SubjectInfo } from "@/lib/queries";
import { estimateMinutes, parseNotebookSyntax } from "@/lib/note-syntax";
import NoteRenderer from "./note-renderer";

const DRAFT_KEY = "commonplace-draft";
const GRADES = ["Class 8", "Class 9", "Class 10", "Class 11", "Class 12"];

const SAMPLE = `Start with one honest paragraph: what is this note about, and who is it for?

## The one thing to remember
!key The core idea :: Write the single sentence your classmates must walk away remembering.

$$ x = (-b ± √(b^2^ - 4ac)) ⁄ 2a :: a formula worth chanting

## How it works
Break the topic into steps, then show them in order:
1. First do this
2. Then notice this
- scattered facts live in bullets
- bullets are friendly

::eg A worked example
= State the problem plainly
= Show each step, one line at a time
= End with the answer in **bold**

> Any line worth quoting goes here :: who said it

| Column | Column |
| a comparison | often clarifies |

!tip Exam wisdom :: What the marker is secretly checking for.
!warn The trap :: The mistake everyone makes, so they stop making it.

---
Close with encouragement. Notes that end kindly get re-read.`;

const CHEAT: [string, string][] = [
  ["## Heading", "new section"],
  ["- item / 1. item", "lists"],
  ["!key T :: text", "key-idea card"],
  ["!tip / !warn T :: text", "tip / warning card"],
  ["$$ formula :: caption", "formula display"],
  ["> quote :: source", "pull quote"],
  ["::eg title + = steps", "worked example"],
  ["| a | b |", "table row (first = header)"],
  ["**bold** *ital* `code`", "inline styles"],
  ["x^2^  H~2~O", "super & subscript"],
  ["---", "divider"],
];

export default function WriteForm({ subjects }: { subjects: SubjectInfo[] }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [grade, setGrade] = useState("Class 10");
  const [subjectSlug, setSubjectSlug] = useState(subjects[0]?.slug ?? "");
  const [excerpt, setExcerpt] = useState("");
  const [content, setContent] = useState("");
  const [mobileView, setMobileView] = useState<"write" | "preview">("write");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [restored, setRestored] = useState(false);
  const skipSave = useRef(true);

  // restore draft
  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const d = JSON.parse(raw) as Partial<{
          title: string;
          author: string;
          grade: string;
          subjectSlug: string;
          excerpt: string;
          content: string;
        }>;
        if (d.title) setTitle(d.title);
        if (d.author) setAuthor(d.author);
        if (d.grade && GRADES.includes(d.grade)) setGrade(d.grade);
        if (d.subjectSlug) setSubjectSlug(d.subjectSlug);
        if (d.excerpt) setExcerpt(d.excerpt);
        if (d.content) setContent(d.content);
        if (d.title || d.content) setRestored(true);
      }
    } catch {
      /* ignore */
    }
    skipSave.current = false;
  }, []);

  // autosave draft
  useEffect(() => {
    if (skipSave.current) return;
    const t = setTimeout(() => {
      try {
        if (!title && !content && !excerpt && !author) {
          localStorage.removeItem(DRAFT_KEY);
          setRestored(false);
          return;
        }
        localStorage.setItem(DRAFT_KEY, JSON.stringify({ title, author, grade, subjectSlug, excerpt, content }));
      } catch {
        /* ignore */
      }
    }, 400);
    return () => clearTimeout(t);
  }, [title, author, grade, subjectSlug, excerpt, content]);

  const blocks = useMemo(() => parseNotebookSyntax(content), [content]);
  const words = useMemo(
    () => content.split(/\s+/).filter(Boolean).length,
    [content],
  );
  const { minutes } = useMemo(() => estimateMinutes(blocks), [blocks]);
  const subject = subjects.find((s) => s.slug === subjectSlug);

  const canSubmit = title.trim().length >= 4 && excerpt.trim().length > 0 && content.trim().length >= 40 && !submitting;

  const submit = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, author, grade, subjectSlug, excerpt, content }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "Publishing failed — try again.");
        return;
      }
      localStorage.removeItem(DRAFT_KEY);
      router.push(`/notes/${data.slug}`);
    } catch {
      setError("Network hiccup — try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const field = "w-full border-b border-ink/25 bg-transparent py-2.5 text-[1rem] text-ink placeholder:text-fog/70 transition-colors focus:border-vermilion focus:outline-none";

  return (
    <div className="mx-auto grid max-w-7xl gap-12 px-5 pb-24 md:px-8 lg:grid-cols-[1.05fr_1fr]">
      {/* ——— the desk (form) ——— */}
      <div className={clsx(mobileView === "preview" && "hidden lg:block")}>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink pb-5">
          <p className="font-mono text-[11px] uppercase tracking-[0.24em] text-vermilion">
            The draft
          </p>
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-fog">
            {restored ? "Draft restored · autosaves locally" : "Autosaves locally"}
          </p>
        </div>

        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Name the note — e.g. Quadratic Equations, Made Simple"
          className="w-full border-b border-ink/25 bg-transparent py-5 font-serif text-3xl font-semibold tracking-tight text-ink placeholder:text-fog/60 focus:border-vermilion focus:outline-none md:text-4xl"
        />

        <textarea
          value={excerpt}
          onChange={(e) => setExcerpt(e.target.value)}
          placeholder="One honest line of summary — what will a classmate have learned after reading this?"
          rows={2}
          className="mt-2 w-full resize-none border-b border-ink/25 bg-transparent py-4 text-[1.05rem] leading-relaxed text-soot placeholder:italic placeholder:text-fog/70 focus:border-vermilion focus:outline-none"
        />

        <div className="mt-6 grid gap-6 sm:grid-cols-2">
          <label className="block">
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">Signed as</span>
            <input
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="Your name (Anonymous is fine)"
              className={field}
            />
          </label>
          <label className="block">
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">For which class</span>
            <select value={grade} onChange={(e) => setGrade(e.target.value)} className={clsx(field, "cursor-pointer")}>
              {GRADES.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="mt-8">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">Shelf</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {subjects.map((s) => (
              <button
                key={s.slug}
                type="button"
                onClick={() => setSubjectSlug(s.slug)}
                className={clsx(
                  "rounded-full border px-4 py-1.5 font-mono text-[10px] uppercase tracking-[0.13em] transition-all duration-300",
                  subjectSlug === s.slug
                    ? "border-ink text-paper shadow-[2px_2px_0_0_#17140c]"
                    : "border-ink/30 text-soot hover:border-ink",
                )}
                style={subjectSlug === s.slug ? { backgroundColor: s.color } : undefined}
              >
                {s.name}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-9">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-fog">
              The note itself
            </p>
            <button
              type="button"
              onClick={() => setContent(SAMPLE)}
              className="font-mono text-[10px] uppercase tracking-[0.16em] text-vermilion underline underline-offset-4 transition-colors hover:text-ink"
            >
              Insert a starter skeleton
            </button>
          </div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={"Write the note here, in notebook syntax.\n\n## First section\nExplain it like you're explaining to a friend one bench over…"}
            rows={16}
            className="mt-3 min-h-[26rem] w-full resize-y border border-ink/30 bg-cream p-5 font-mono text-[13px] leading-[1.9] text-ink placeholder:italic placeholder:text-fog/60 focus:border-vermilion focus:outline-none"
          />
          <div className="mt-2 flex flex-wrap justify-between gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-fog">
            <span>{words} words</span>
            <span>≈ {minutes} min read</span>
          </div>
        </div>

        {error && (
          <div className="mt-6 flex items-start gap-2.5 border border-vermilion-deep bg-[#fbe9dd] p-4 text-sm text-vermilion-deep">
            <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <div className="mt-8 flex flex-wrap items-center gap-4">
          <button
            onClick={submit}
            disabled={!canSubmit}
            className={clsx(
              "group inline-flex items-center gap-2.5 rounded-full border border-ink px-8 py-4 font-mono text-[11px] uppercase tracking-[0.16em] transition-all duration-300",
              canSubmit
                ? "bg-vermilion text-paper shadow-[4px_4px_0_0_#17140c] hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[2px_2px_0_0_#17140c]"
                : "cursor-not-allowed border-ink/30 bg-ink/5 text-fog",
            )}
          >
            {submitting ? (
              <LoaderCircle className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            )}
            {submitting ? "Publishing…" : "Publish to the notebook"}
          </button>
          {!canSubmit && (
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-fog">
              Needs a title, a summary & 40+ characters of substance
            </p>
          )}
        </div>

        {/* cheat sheet */}
        <div className="mt-12 border border-ink/40">
          <p className="border-b border-ink/40 bg-ink px-5 py-2.5 font-mono text-[10px] uppercase tracking-[0.24em] text-paper">
            Notebook syntax — a cheat sheet
          </p>
          <div className="grid sm:grid-cols-2">
            {CHEAT.map(([syntax, meaning], i) => (
              <div
                key={syntax}
                className={clsx(
                  "flex items-baseline justify-between gap-3 border-ink/15 px-5 py-2.5",
                  i % 2 === 0 ? "sm:border-r" : "",
                  "border-b last:border-b-0 sm:[&:nth-last-child(2)]:border-b-0",
                )}
              >
                <code className="font-mono text-[11px] text-ink">{syntax}</code>
                <span className="text-right text-[11px] text-fog">{meaning}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ——— the proof sheet (preview) ——— */}
      <div className={clsx(mobileView === "write" && "hidden lg:block")}>
        <div className="lg:sticky lg:top-24">
          <div className="flex items-center justify-between border-b border-ink pb-5">
            <p className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.24em] text-vermilion">
              <Eye className="h-3.5 w-3.5" />
              The proof sheet
            </p>
            {subject && (
              <span
                className="rounded-full px-3 py-1 font-mono text-[9px] uppercase tracking-[0.16em]"
                style={{ backgroundColor: subject.color, color: subject.ink }}
              >
                {subject.name}
              </span>
            )}
          </div>

          <div className="mt-6 max-h-[70vh] overflow-y-auto border border-ink/60 bg-cream p-6 shadow-[8px_8px_0_0_rgba(23,20,12,0.12)] md:p-9">
            {title || content ? (
              <>
                <h2 className="font-serif text-3xl font-semibold leading-tight tracking-tight">
                  {title || "Untitled note"}
                </h2>
                <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.18em] text-fog">
                  {author.trim() || "Anonymous"} · {grade} · ≈ {minutes} min
                </p>
                {excerpt && (
                  <p className="mt-5 border-l-2 border-vermilion pl-4 text-[15px] italic leading-relaxed text-soot">
                    {excerpt}
                  </p>
                )}
                <div className="mt-8">
                  {blocks.length ? (
                    <NoteRenderer blocks={blocks} />
                  ) : (
                    <p className="text-sm italic text-fog">The proof sheet fills in as you write…</p>
                  )}
                </div>
              </>
            ) : (
              <div className="flex min-h-72 flex-col items-center justify-center gap-4 text-center">
                <PenLine className="h-6 w-6 text-fog" />
                <p className="max-w-60 font-serif text-xl italic text-fog">
                  Start writing on the left — the page appears here, live.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* mobile write/preview toggle */}
      <div className="fixed bottom-5 left-1/2 z-40 -translate-x-1/2 lg:hidden">
        <div className="flex overflow-hidden rounded-full border border-ink bg-ink shadow-[4px_4px_0_0_rgba(23,20,12,0.3)]">
          {(["write", "preview"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setMobileView(v)}
              className={clsx(
                "px-6 py-2.5 font-mono text-[10px] uppercase tracking-[0.16em] transition-colors",
                mobileView === v ? "bg-vermilion text-paper" : "text-paper/70",
              )}
            >
              {v}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
