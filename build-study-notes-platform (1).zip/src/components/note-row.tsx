import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { NoteListItem } from "@/lib/queries";

export default function NoteRow({
  note,
  index,
  dark = false,
}: {
  note: NoteListItem;
  index: number;
  dark?: boolean;
}) {
  return (
    <Link
      href={`/notes/${note.slug}`}
      className="group grid grid-cols-[auto_1fr_auto] items-baseline gap-x-4 border-b border-ink/15 py-5 transition-colors duration-300 hover:bg-ink hover:text-paper md:grid-cols-[3rem_1fr_auto_auto_2.5rem] md:gap-x-6 md:px-4"
    >
      <span className="font-mono text-xs tracking-[0.18em] text-fog transition-colors group-hover:text-paper/50">
        {String(index + 1).padStart(2, "0")}
      </span>
      <span className="min-w-0">
        <span className="block truncate font-serif text-xl font-medium tracking-tight transition-transform duration-300 group-hover:translate-x-1.5 md:text-[1.45rem]">
          {note.title}
        </span>
        <span className="mt-0.5 block font-mono text-[10px] uppercase tracking-[0.16em] text-fog group-hover:text-paper/50 md:hidden">
          {note.subject.name} · {note.readMinutes} min
        </span>
      </span>
      <span
        className="hidden font-mono text-[10px] uppercase tracking-[0.16em] md:block"
        style={{ color: dark ? note.subject.ink : note.subject.color }}
      >
        {note.subject.name}
      </span>
      <span className="hidden font-mono text-[10px] uppercase tracking-[0.16em] text-fog transition-colors group-hover:text-paper/50 md:block">
        {note.readMinutes} min
      </span>
      <ArrowRight className="h-4 w-4 justify-self-end text-fog transition-all duration-300 group-hover:translate-x-1 group-hover:text-paper" />
    </Link>
  );
}
