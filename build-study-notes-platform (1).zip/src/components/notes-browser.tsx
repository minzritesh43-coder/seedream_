"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { ArrowDownWideNarrow, PenLine, Search, X } from "lucide-react";
import clsx from "clsx";
import type { NoteListItem, SubjectInfo } from "@/lib/queries";
import NoteCard from "./note-card";

type SortKey = "newest" | "popular" | "quickest";

export default function NotesBrowser({
  notes,
  subjects,
}: {
  notes: NoteListItem[];
  subjects: SubjectInfo[];
}) {
  const [q, setQ] = useState("");
  const [active, setActive] = useState<string | null>(null);
  const [sort, setSort] = useState<SortKey>("newest");

  const filtered = useMemo(() => {
    let list = notes;
    if (active) list = list.filter((n) => n.subject.slug === active);
    const needle = q.trim().toLowerCase();
    if (needle) {
      list = list.filter(
        (n) =>
          n.title.toLowerCase().includes(needle) ||
          n.excerpt.toLowerCase().includes(needle) ||
          n.author.toLowerCase().includes(needle) ||
          n.subject.name.toLowerCase().includes(needle),
      );
    }
    const sorted = [...list];
    if (sort === "popular") sorted.sort((a, b) => b.views - a.views);
    else if (sort === "quickest") sorted.sort((a, b) => a.readMinutes - b.readMinutes);
    else sorted.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
    return sorted;
  }, [notes, q, active, sort]);

  return (
    <div>
      {/* controls */}
      <div className="border-b border-ink/60 bg-paper">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <label className="group flex items-center gap-3 border-b border-ink/15 py-4 transition-colors focus-within:border-vermilion">
            <Search className="h-4 w-4 text-fog" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search trigonometry, photosynthesis, Big-O…"
              className="w-full bg-transparent font-serif text-xl italic tracking-tight text-ink placeholder:text-fog/70 focus:outline-none md:text-2xl"
            />
            {q && (
              <button
                onClick={() => setQ("")}
                className="rounded-full p-1 text-fog transition-colors hover:bg-ink/8 hover:text-ink"
                aria-label="Clear search"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </label>

          <div className="scroll-slim flex items-center gap-2 overflow-x-auto py-4">
            <button
              onClick={() => setActive(null)}
              className={clsx(
                "whitespace-nowrap rounded-full border px-4 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] transition-all duration-300",
                active === null
                  ? "border-ink bg-ink text-paper"
                  : "border-ink/30 text-soot hover:border-ink",
              )}
            >
              Everything ({notes.length})
            </button>
            {subjects.map((s) => (
              <button
                key={s.slug}
                onClick={() => setActive(active === s.slug ? null : s.slug)}
                className={clsx(
                  "whitespace-nowrap rounded-full border px-4 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] transition-all duration-300",
                  active === s.slug
                    ? "border-ink text-paper shadow-[2px_2px_0_0_#17140c]"
                    : "border-ink/30 text-soot hover:border-ink",
                )}
                style={active === s.slug ? { backgroundColor: s.color, borderColor: "#17140c" } : undefined}
              >
                {s.name} ({s.noteCount ?? 0})
              </button>
            ))}

            <div className="ml-auto flex shrink-0 items-center gap-2 pl-4">
              <ArrowDownWideNarrow className="h-3.5 w-3.5 text-fog" />
              {(
                [
                  ["newest", "Newest"],
                  ["popular", "Most read"],
                  ["quickest", "Quickest"],
                ] as [SortKey, string][]
              ).map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setSort(key)}
                  className={clsx(
                    "font-mono text-[10px] uppercase tracking-[0.14em] transition-colors",
                    sort === key ? "text-vermilion underline underline-offset-4" : "text-fog hover:text-ink",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* grid */}
      <div className="mx-auto max-w-7xl px-5 py-12 md:px-8 md:py-16">
        <p className="mb-8 font-mono text-[10px] uppercase tracking-[0.22em] text-fog">
          Showing {filtered.length} of {notes.length} notes
          {active && ` · ${subjects.find((s) => s.slug === active)?.name}`}
        </p>

        {filtered.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((n, i) => (
              <NoteCard key={n.slug} note={n} index={i} />
            ))}
          </div>
        ) : (
          <div className="mx-auto max-w-lg border border-dashed border-ink/40 bg-cream p-12 text-center">
            <p className="font-serif text-2xl italic">Nothing on this shelf yet.</p>
            <p className="mt-3 text-sm leading-relaxed text-soot/80">
              That gap is an invitation — the best class notes are the ones someone
              finally writes down.
            </p>
            <Link
              href="/write"
              className="mt-6 inline-flex items-center gap-2 rounded-full border border-ink bg-vermilion px-6 py-3 font-mono text-[10px] uppercase tracking-[0.16em] text-paper shadow-[3px_3px_0_0_#17140c] transition-all duration-300 hover:translate-x-[1px] hover:translate-y-[1px] hover:shadow-[1px_1px_0_0_#17140c]"
            >
              <PenLine className="h-3.5 w-3.5" />
              Write the first one
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
